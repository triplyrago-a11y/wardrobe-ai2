package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.WardrobeItem
import com.example.ui.components.FloatingLiquidGlassCard
import com.example.ui.components.LiquidGlassCard
import com.example.ui.viewmodel.WardrobeViewModel
import kotlinx.coroutines.launch

private val EaseInOutSine = Easing { fraction ->
    -(kotlin.math.cos(Math.PI * fraction) - 1f).toFloat() / 2f
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WardrobeScreen(
    viewModel: WardrobeViewModel,
    modifier: Modifier = Modifier
) {
    val items by viewModel.allWardrobeItems.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedCategoryTab by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    
    val coroutineScope = rememberCoroutineScope()
    val gridState = rememberLazyStaggeredGridState()

    // 7 Specified Categories + "All" for convenient master viewing
    val categories = listOf("All", "Jeans", "Shirts", "Tshirts", "Hoodies", "Jackets", "Shoes", "Accessories")

    // Filter items based on active search text and the category tab
    val filteredItems = remember(items, selectedCategoryTab, searchQuery) {
        items.filter { item ->
            val matchesCategory = selectedCategoryTab == "All" || item.category.lowercase() == selectedCategoryTab.lowercase()
            val matchesSearch = searchQuery.isBlank() || 
                    item.name.contains(searchQuery, ignoreCase = true) ||
                    item.colorName.contains(searchQuery, ignoreCase = true) ||
                    (item.description?.contains(searchQuery, ignoreCase = true) == true)
            matchesCategory && matchesSearch
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            // Elegant spacing at the top
            Spacer(modifier = Modifier.statusBarsPadding())
            Spacer(modifier = Modifier.height(20.dp))

            // Screen Header Section (Material 3 Expressive styling)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WARDROBE AI / COLLECTION",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp,
                            color = com.example.ui.theme.TextLight
                        )
                    )
                    Text(
                        text = "Digital Capsule",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontSize = 30.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.SansSerif,
                            color = com.example.ui.theme.TextDark
                        )
                    )
                }

                // Glass-trimmed expressive floating Add Button
                IconButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier
                        .testTag("add_garment_button")
                        .size(52.dp)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF4285F4),
                                    Color(0xFF7C4DFF)
                                )
                            ),
                            shape = CircleShape
                        )
                        .border(
                            width = 1.2.dp,
                            color = Color.White.copy(alpha = 0.65f),
                            shape = CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Item",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            // Glassmorphic Search Bar: corners 40, background alpha 0.25, specular diagonals
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(40.dp))
                    .background(Color.White.copy(alpha = 0.25f))
                    .border(
                        width = 1.2.dp,
                        color = Color.White.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(40.dp)
                    )
                    .drawBehind {
                        val w = size.width
                        val h = size.height
                        // Dynamic glossy light-sweep reflection
                        val gloss = Brush.linearGradient(
                            colors = listOf(Color.White.copy(alpha = 0.15f), Color.Transparent),
                            start = Offset(0f, 0f),
                            end = Offset(w * 0.35f, h)
                        )
                        drawRect(brush = gloss)
                    }
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = com.example.ui.theme.TextLight,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))

                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        textStyle = TextStyle(
                            color = com.example.ui.theme.TextDark,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.SansSerif
                        ),
                        cursorBrush = SolidColor(com.example.ui.theme.WardrobePrimary),
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        decorationBox = { innerTextField ->
                            if (searchQuery.isEmpty()) {
                                Text(
                                    text = "Search collection pieces...",
                                    color = com.example.ui.theme.TextLight.copy(alpha = 0.8f),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium,
                                    fontFamily = FontFamily.SansSerif
                                )
                            }
                            innerTextField()
                        }
                    )

                    if (searchQuery.isNotEmpty()) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear",
                            tint = com.example.ui.theme.TextLight,
                            modifier = Modifier
                                .size(18.dp)
                                .clickable { searchQuery = "" }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Animated Filter Chips Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                categories.forEach { category ->
                    val isSelected = selectedCategoryTab == category
                    
                    // Spring-morphed horizontal padding & scaling feedback
                    val chipScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.05f else 1.0f,
                        animationSpec = spring(dampingRatio = 0.72f, stiffness = 160f),
                        label = "chip_scale_anim"
                    )
                    
                    val activeColor1 = Color(0xFF4285F4)
                    val activeColor2 = Color(0xFF00D4FF)

                    Box(
                        modifier = Modifier
                            .scale(chipScale)
                            .clip(RoundedCornerShape(24.dp))
                            .border(
                                width = if (isSelected) 1.5.dp else 1.0.dp,
                                color = if (isSelected) Color.White.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(24.dp)
                            )
                            .background(
                                brush = if (isSelected) {
                                    Brush.linearGradient(colors = listOf(activeColor1, activeColor2))
                                } else {
                                    Brush.linearGradient(
                                        colors = listOf(
                                            Color.White.copy(alpha = 0.35f),
                                            Color.White.copy(alpha = 0.15f)
                                        )
                                    )
                                },
                                shape = RoundedCornerShape(24.dp)
                            )
                            .clickable {
                                selectedCategoryTab = category
                                coroutineScope.launch {
                                    gridState.animateScrollToItem(0)
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                            .drawBehind {
                                if (isSelected) {
                                    // Soft surrounding active radial glow
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            colors = listOf(Color(0xFF00D4FF).copy(alpha = 0.4f), Color.Transparent),
                                            radius = size.width * 1.5f
                                        ),
                                        radius = size.width * 1.5f
                                    )
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = if (category == "All") Icons.Default.AllInclusive else getCategoryIcon(category),
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier
                                        .size(14.dp)
                                        .padding(end = 2.dp)
                                )
                            }
                            Text(
                                text = category,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                                color = if (isSelected) Color.White else com.example.ui.theme.TextDark,
                                fontFamily = FontFamily.SansSerif
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Main Workspace: Pinterest Masonry Grid or Empty State
            if (filteredItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AllInclusive,
                            contentDescription = "Empty Grid",
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No wardrobe pieces match.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.TextDark
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Tap the '+' corner icon above to define a custom garment or scan with AI.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = com.example.ui.theme.TextLight,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                // Pinterest Masonry Staggered Grid setup
                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(2),
                    state = gridState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalItemSpacing = 16.dp,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 120.dp) // extra padding bottom for the floating dock overlay
                ) {
                    items(
                        items = filteredItems,
                        key = { it.id }
                    ) { wardrobeItem ->
                        // Calculate parallax factor based on scrolled elements index and grid scroll state
                        val firstIndex = gridState.firstVisibleItemIndex
                        val firstScrollOffset = gridState.firstVisibleItemScrollOffset
                        val parallaxY = remember(firstIndex, firstScrollOffset) {
                            val absoluteRelative = (firstIndex * 260 + firstScrollOffset)
                            ((absoluteRelative * 0.08f) % 40f) - 20f
                        }

                        MasonryWardrobeCard(
                            item = wardrobeItem,
                            parallaxY = parallaxY,
                            onDelete = { viewModel.removeWardrobeItem(wardrobeItem) }
                        )
                    }
                }
            }
        }

        // Add Garment Dialog Modal popup
        if (showAddDialog) {
            AddGarmentDialog(
                onDismiss = { showAddDialog = false },
                onAdd = { name, category, colorName, colorHex, desc ->
                    viewModel.addWardrobeItem(name, category, colorName, colorHex, desc)
                    showAddDialog = false
                }
            )
        }
    }
}

/**
 * Custom Pinterest Masonry Grid Card (Liquid Glass with Rounded-32 corners)
 * Features entrance scale reveal, gentle floating float loops, parallax imagery, and tiny top delete corner button.
 */
@Composable
fun MasonryWardrobeCard(
    item: WardrobeItem,
    parallaxY: Float,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 1. Entrance Reveal: Scales and fades in dynamically upon scrolling into composition
    var isRevealed by remember { mutableStateOf(false) }
    LaunchedEffect(key1 = item.id) {
        isRevealed = true
    }
    val scaleReveal by animateFloatAsState(
        targetValue = if (isRevealed) 1f else 0.85f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "reveal_scale"
    )
    val alphaReveal by animateFloatAsState(
        targetValue = if (isRevealed) 1f else 0f,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "reveal_alpha"
    )

    // 2. Slow oscillating Floating Motion (Subtle staggered vertical float drift loop)
    val infiniteFloat = rememberInfiniteTransition(label = "floating_drift_${item.id}")
    val floatOffsetAmt by infiniteFloat.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 2800 + (item.id * 180) % 1200, // staggered cycle lengths
                easing = EaseInOutSine
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "floating_offset"
    )

    // Calculate organic card heights typical of high-quality Pinterest grids
    val itemHeight = remember(item) {
        val baseHeight = when (item.category.lowercase()) {
            "jeans" -> 210
            "shirts" -> 190
            "tshirts" -> 180
            "hoodies" -> 230
            "jackets" -> 240
            "shoes" -> 170
            "accessories" -> 150
            else -> 200
        }
        val textLengthAdjustment = (item.name.length * 1.25f).toInt().coerceAtMost(36)
        (baseHeight + textLengthAdjustment).dp
    }

    val itemColor = remember(item.colorHex) {
        try {
            Color(android.graphics.Color.parseColor(item.colorHex))
        } catch (e: Exception) {
            Color(0xFF4285F4) // fallbacks to signature cobalt blue
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(itemHeight)
            .graphicsLayer {
                scaleX = scaleReveal
                scaleY = scaleReveal
                alpha = alphaReveal
                translationY = floatOffsetAmt
            }
            .clip(RoundedCornerShape(32.dp)) // Strictly Rounded-32
            .border(
                width = 1.2.dp,
                color = Color.White.copy(alpha = 0.55f),
                shape = RoundedCornerShape(32.dp)
            )
            .background(Color.White.copy(alpha = 0.2f))
    ) {
        // IMAGE FILLS CARD: Full bleed layout representing clothing visually
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            if (!item.imageUrl.isNullOrBlank()) {
                // If camera upload is present, stretch it to fill the entire card
                AsyncImage(
                    model = item.imageUrl,
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // Generate a high-fashion, premium dynamic fluid abstract background representation 
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .drawBehind {
                            val w = size.width
                            val h = size.height

                            // Draw structured linear gradient matching item hex-color and rich shadows
                            drawRect(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        itemColor.copy(alpha = 0.85f),
                                        itemColor.copy(alpha = 0.45f).compositeOver(Color.DarkGray)
                                    ),
                                    start = Offset(0f, 0f),
                                    end = Offset(w, h)
                                )
                            )

                            // 2-Layer animated Parallax mesh waves
                            val parallaxShift = parallaxY * 2.5f

                            // Abstract Wave Shape 1
                            drawCircle(
                                color = Color.White.copy(alpha = 0.18f),
                                radius = w * 0.7f,
                                center = Offset(w * 0.1f, (h * 0.2f) + parallaxShift)
                            )

                            // Abstract Wave Shape 2
                            drawCircle(
                                color = Color.Black.copy(alpha = 0.08f),
                                radius = w * 0.5f,
                                center = Offset(w * 0.8f, (h * 0.7f) - parallaxShift)
                            )

                            // Clean diagonal liquid gloss specular light sweep
                            drawRect(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.12f),
                                        Color.Transparent
                                    ),
                                    start = Offset(0f, 0f),
                                    end = Offset(w * 0.45f, h * 0.5f)
                                )
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    // Minimal centered structural category icon
                    Icon(
                        imageVector = getCategoryIcon(item.category),
                        contentDescription = null,
                        tint = if (isLightColor(itemColor)) Color.Black.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.6f),
                        modifier = Modifier
                            .graphicsLayer {
                                translationY = -parallaxY * 0.8f // Parallax floating shift for centered item
                            }
                            .size(52.dp)
                    )
                }
            }

            // Translucent Frosted Glass caption plate at the bottom (minimal label)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .background(Color.Black.copy(alpha = 0.35f)) // frosted tint for superb contrast
                    .drawBehind {
                        // Dynamic card gloss inside plate
                        val reflection = Brush.linearGradient(
                            colors = listOf(Color.White.copy(alpha = 0.1f), Color.Transparent),
                            start = Offset(0f, 0f),
                            end = Offset(size.width, size.height)
                        )
                        drawRect(brush = reflection)
                    }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Column {
                    // Small Minimal Label
                    Text(
                        text = item.name,
                        style = TextStyle(
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.SansSerif
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Category Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.White.copy(alpha = 0.25f))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = item.category,
                                style = TextStyle(
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    letterSpacing = 0.6.sp
                                )
                            )
                        }

                        // Tiny circular color indicator
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(itemColor)
                                .border(1.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                        )
                    }
                }
            }

            // Tiny glass-morphed circle delete button on top-right hand corner
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(14.dp)
                    .testTag("delete_item_${item.id}")
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.35f))
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.45f),
                        shape = CircleShape
                    )
                    .clickable { onDelete() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Delete Piece",
                    tint = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

/**
 * Add Garment Dialog Modal with Glass Theme and precise specified categories
 */
@Composable
fun AddGarmentDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, category: String, colorName: String, colorHex: String, description: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    // Enforces Jeans as the default selected category
    var selectedCategory by remember { mutableStateOf("Jeans") }
    var selectedColorName by remember { mutableStateOf("Classic Indigo Blue") }
    var selectedColorHex by remember { mutableStateOf("#4B6F96") }
    var description by remember { mutableStateOf("") }

    // Explicit 7 requested categories
    val categories = listOf("Jeans", "Shirts", "Tshirts", "Hoodies", "Jackets", "Shoes", "Accessories")

    // Fashion curation palette
    val colorsPalette = listOf(
        Triple("Classic Indigo Blue", "#4B6F96", Color(0xFF4B6F96)),
        Triple("Charcoal Black", "#1D1E2C", Color(0xFF1D1E2C)),
        Triple("Camel Beige", "#C19A6B", Color(0xFFC19A6B)),
        Triple("Slate Grey", "#7A8A99", Color(0xFF7A8A99)),
        Triple("Cream Silk", "#FAFAF2", Color(0xFFFAFAF2)),
        Triple("Sage Green", "#9CAF88", Color(0xFF9CAF88)),
        Triple("Washed Orange", "#E2725B", Color(0xFFE2725B)),
        Triple("Cozy Oatmeal", "#E5DCD3", Color(0xFFE5DCD3))
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .border(1.dp, Color.White.copy(alpha = 0.55f), RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Add Collection Piece",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = com.example.ui.theme.TextDark,
                        fontFamily = FontFamily.SansSerif
                    )
                )
                Text(
                    text = "Specify details to place item inside your digital capsule.",
                    style = MaterialTheme.typography.bodySmall,
                    color = com.example.ui.theme.TextLight,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Garment Name (e.g. Vintage 501)") },
                    placeholder = { Text("E.g., Heavyweight Indigo Denim") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_garment_name_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Staggered categories selector
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Category Grid Target",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = com.example.ui.theme.TextLight
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.forEach { category ->
                            val isSelected = selectedCategory == category
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.15f)
                                    )
                                    .clickable { selectedCategory = category }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = category,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else com.example.ui.theme.TextDark
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Swatch choice selector
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Color Hue Selection",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.TextLight
                        )
                        Text(
                            text = selectedColorName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        colorsPalette.forEach { (cName, cHex, colorVal) ->
                            val isSelected = selectedColorHex == cHex
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(colorVal)
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.secondary else Color.LightGray.copy(alpha = 0.5f),
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        selectedColorName = cName
                                        selectedColorHex = cHex
                                    }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description / Fit profile") },
                    placeholder = { Text("E.g., relaxed taper fit, soft texture") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            if (name.trim().isNotEmpty()) {
                                onAdd(name, selectedCategory, selectedColorName, selectedColorHex, description)
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_garment_button"),
                        enabled = name.trim().isNotEmpty()
                    ) {
                        Text("Add Piece")
                    }
                }
            }
        }
    }
}

/**
 * Maps category tags to modern, stylish Material Symbols vector representations.
 */
fun getCategoryIcon(category: String): ImageVector {
    return when (category.lowercase()) {
        "jeans" -> Icons.Default.Layers       // represents layered high-fashion denim structure
        "shirts" -> Icons.Default.Checkroom
        "tshirts" -> Icons.Default.Checkroom
        "hoodies" -> Icons.Default.Checkroom
        "jackets" -> Icons.Default.Checkroom
        "shoes" -> Icons.Default.Checkroom
        "accessories" -> Icons.Default.Palette
        else -> Icons.Default.ShoppingBag
    }
}

/**
 * Accessibility luminance formula (checks if text should be white or black based on backing tint)
 */
fun isLightColor(color: Color): Boolean {
    val luminance = 0.2126 * color.red + 0.7152 * color.green + 0.0722 * color.blue
    return luminance > 0.65
}
