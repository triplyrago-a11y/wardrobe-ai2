package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.MeshGradientBackground
import com.example.ui.viewmodel.WardrobeViewModel
import android.app.Application
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.AuthState

private val EaseInOutSine = Easing { fraction ->
    -(kotlin.math.cos(Math.PI * fraction) - 1f).toFloat() / 2f
}

@Composable
fun MainAppScreen(
    viewModel: WardrobeViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val authViewModel: AuthViewModel = viewModel(
        factory = AuthViewModel.Factory(context.applicationContext as Application)
    )
    val authState by authViewModel.authState.collectAsState()
    val isLoggedIn = authState is AuthState.LoggedIn

    var currentTab by remember { mutableStateOf("Home") }
    var showSplash by remember { mutableStateOf(true) }

    MeshGradientBackground {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Screen Switching Workspace Content
            Box(
                modifier = Modifier.fillMaxSize()
            ) {
                if (!showSplash && !isLoggedIn) {
                    AuthScreensHandler(
                        viewModel = authViewModel,
                        onAuthSuccess = { _, _ -> }
                    )
                } else {
                    Crossfade(
                        targetState = currentTab,
                        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                        label = "tab_crossfade"
                    ) { tab ->
                        when (tab) {
                            "Home" -> {
                                HomeScreen(
                                    viewModel = viewModel,
                                    onNavigateToTab = { currentTab = it }
                                )
                            }
                            "Wardrobe" -> {
                                WardrobeScreen(viewModel = viewModel)
                            }
                            "Scan" -> {
                                ScanningScreen(viewModel = viewModel)
                            }
                            "Outfits" -> {
                                OutfitsScreen(viewModel = viewModel)
                            }
                            "Profile" -> {
                                StyleGuideScreen(
                                    viewModel = viewModel,
                                    onLogout = { authViewModel.logOut() }
                                )
                            }
                        }
                    }
                }
            }

            // High-End Liquid Glass Floating Bottom Navigation
            if (!showSplash && isLoggedIn) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 16.dp)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    FloatingGlassDockBar(
                        selectedTab = currentTab,
                        onTabSelected = { currentTab = it }
                    )
                }
            }

            // Floating premium visual presence (AI Aura)
            if (!showSplash && isLoggedIn) {
                val infiniteGlow = rememberInfiniteTransition(label = "gemini_persistence")
                val floatAnim by infiniteGlow.animateFloat(
                    initialValue = -5f,
                    targetValue = 5f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(2200, easing = EaseInOutSine),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "gemini_float"
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(top = 16.dp, end = 20.dp)
                        .size(28.dp)
                        .offset(y = floatAnim.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val r = this.size.width / 2f
                        
                        // Aura glow
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF7C4DFF).copy(alpha = 0.45f),
                                    Color(0xFF4285F4).copy(alpha = 0.15f),
                                    Color.Transparent
                                ),
                                center = Offset(r, r),
                                radius = r * 2.8f
                            ),
                            center = Offset(r, r),
                            radius = r * 2.8f
                        )

                        // Rainbow colorful sweep gradient center core
                        drawCircle(
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    Color(0xFF4285F4),
                                    Color(0xFF00D4FF),
                                    Color(0xFFFF5FA2),
                                    Color(0xFF7C4DFF),
                                    Color(0xFF4285F4)
                                ),
                                center = Offset(r, r)
                            ),
                            center = Offset(r, r),
                            radius = r * 0.95f
                        )

                        // Solid bright center core
                        drawCircle(
                            color = Color.White.copy(alpha = 0.9f),
                            radius = r * 0.45f,
                            center = Offset(r, r)
                        )
                    }
                }
            }

            // Animated Splash Screen Overlay with cinematic GPU hardware-accelerated fade-out
            AnimatedVisibility(
                visible = showSplash,
                enter = fadeIn(),
                exit = fadeOut(
                    animationSpec = tween(750, easing = EaseInOutSine)
                )
            ) {
                SplashScreen(
                    onFinished = { showSplash = false }
                )
            }
        }
    }
}

@Composable
fun FloatingGlassDockBar(
    selectedTab: String,
    onTabSelected: (String) -> Unit
) {
    Box(
        modifier = Modifier,
        contentAlignment = Alignment.BottomCenter
    ) {
        // Floating Pill Shape: Width 85%, Height 72dp, Corners 40dp
        Row(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .height(72.dp)
                .shadow(
                    elevation = 16.dp,
                    shape = RoundedCornerShape(40.dp),
                    clip = false
                )
                .clip(RoundedCornerShape(40.dp))
                .background(Color.White.copy(alpha = 0.2f)) // Opacity 0.2 Glass
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.45f), // Rim highlight border
                    shape = RoundedCornerShape(40.dp)
                )
                .drawBehind {
                    // Specular reflection diagonal sweep
                    val w = size.width
                    val h = size.height
                    val reflectionSweep = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.15f),
                            Color.White.copy(alpha = 0.05f),
                            Color.Transparent
                        ),
                        start = Offset(0f, 0f),
                        end = Offset(w * 0.45f, h)
                    )
                    drawRect(brush = reflectionSweep)
                }
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tab 1: Home
            FloatingGlassTabItem(
                id = "Home",
                label = "Home",
                selectedIcon = Icons.Filled.Home,
                unselectedIcon = Icons.Outlined.Home,
                isSelected = selectedTab == "Home",
                onClick = { onTabSelected("Home") }
            )

            // Tab 2: Wardrobe
            FloatingGlassTabItem(
                id = "Wardrobe",
                label = "Wardrobe",
                selectedIcon = Icons.Filled.ShoppingBag,
                unselectedIcon = Icons.Outlined.ShoppingBag,
                isSelected = selectedTab == "Wardrobe",
                onClick = { onTabSelected("Wardrobe") }
            )

            // Dynamic Spatial Center placeholder for floating overlay
            Box(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                // Symmetrical separation spacer
            }

            // Tab 4: Outfits
            FloatingGlassTabItem(
                id = "Outfits",
                label = "Outfits",
                selectedIcon = Icons.Filled.Palette,
                unselectedIcon = Icons.Outlined.Palette,
                isSelected = selectedTab == "Outfits",
                onClick = { onTabSelected("Outfits") }
            )

            // Tab 5: Profile
            FloatingGlassTabItem(
                id = "Profile",
                label = "Profile",
                selectedIcon = Icons.Filled.Person,
                unselectedIcon = Icons.Outlined.Person,
                isSelected = selectedTab == "Profile",
                onClick = { onTabSelected("Profile") }
            )
        }

        // Floating Center Scan Button: Large Circle overlapping the bar
        FloatingCenterScanButton(
            onClick = { onTabSelected("Scan") }
        )
    }
}

@Composable
fun RowScope.FloatingGlassTabItem(
    id: String,
    label: String,
    selectedIcon: ImageVector,
    unselectedIcon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val transition = updateTransition(targetState = isSelected, label = "tab_select_$id")
    
    // Smooth Icon size expanding with Spring Physics
    val iconScale by transition.animateFloat(
        transitionSpec = {
            spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            )
        },
        label = "icon_scale"
    ) { selected ->
        if (selected) 1.25f else 1.0f
    }

    // Smooth transparency text fade
    val labelAlpha by transition.animateFloat(
        transitionSpec = { tween(250) },
        label = "label_alpha"
    ) { selected ->
        if (selected) 1.0f else 0.0f
    }

    Box(
        modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clip(RoundedCornerShape(30.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = Color(0xFF4285F4).copy(alpha = 0.2f)),
                onClick = onClick
            )
            .testTag("nav_tab_${id.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Under-icon selection glass bubble & radial blue glow
            Box(
                modifier = Modifier
                    .size(if (isSelected) 42.dp else 36.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) Color.White.copy(alpha = 0.25f) else Color.Transparent
                    )
                    .border(
                        width = 1.dp,
                        color = if (isSelected) Color.White.copy(alpha = 0.45f) else Color.Transparent,
                        shape = CircleShape
                    )
                    .drawBehind {
                        if (isSelected) {
                            // Radial blue glow underlying
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(Color(0xFF4285F4).copy(alpha = 0.35f), Color.Transparent),
                                    radius = size.width * 1.15f
                                ),
                                radius = size.width * 1.15f
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isSelected) selectedIcon else unselectedIcon,
                    contentDescription = label,
                    tint = if (isSelected) Color(0xFF4169E1) else Color(0xFF64748B),
                    modifier = Modifier.scale(iconScale)
                )
            }

            // Sub-label text
            if (isSelected) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = label,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4169E1),
                    modifier = Modifier.graphicsLayer(alpha = labelAlpha)
                )
            }
        }
    }
}

@Composable
fun FloatingCenterScanButton(
    onClick: () -> Unit
) {
    // Pulse animation loop
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_loop")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    val pulseGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.40f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_glow"
    )

    // Tap Interaction source tracking
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Smooth Spring physics feedback for pressed scale and morphed corners!
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 1.22f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ), label = "press_feedback"
    )
    
    val pressMorphCorner by animateIntAsState(
        targetValue = if (isPressed) 18 else 32,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ), label = "press_morph"
    )

    Box(
        modifier = Modifier
            .offset(y = (-18).dp) // elevates above the bottom bar
            .size(64.dp)
            .scale(pulseScale * pressScale)
            .shadow(
                elevation = 8.dp,
                shape = RoundedCornerShape(pressMorphCorner.dp),
                clip = false
            )
            .clip(RoundedCornerShape(pressMorphCorner.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF4285F4), // Blue
                        Color(0xFF7C4DFF)  // Purple
                    )
                )
            )
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = Color.White),
                onClick = onClick
            )
            .drawBehind {
                // AI pulsing aura ring glow
                drawCircle(
                    color = Color(0xFF7C4DFF).copy(alpha = pulseGlowAlpha),
                    radius = size.width * 0.72f,
                    style = Stroke(width = 3f)
                )
            }
            .testTag("nav_tab_scan_center"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Top transparent glass specular accent reflecting a real droplet shine
            drawContext.canvas.save()
            val specularBrush = Brush.linearGradient(
                colors = listOf(Color.White.copy(alpha = 0.35f), Color.Transparent),
                start = Offset(0f, 0f),
                end = Offset(0f, h * 0.45f)
            )
            drawRect(brush = specularBrush)
            drawContext.canvas.restore()

            // Dynamic high-end outer container rim
            drawCircle(
                color = Color.White.copy(alpha = 0.45f),
                radius = w / 2f,
                style = Stroke(width = 1.0f)
            )
        }

        Icon(
            imageVector = Icons.Filled.AutoAwesome,
            contentDescription = "Scan AI",
            tint = Color.White,
            modifier = Modifier
                .size(28.dp)
                .rotate(if (isPressed) 45f else 0f) // morph rotating on pressed
        )
    }
}

data class DockItem(
    val id: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)
