package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val WardrobeBackground = Color(0xFFF8FAFF)
val WardrobePrimary = Color(0xFF4285F4)
val WardrobeSecondary = Color(0xFF7C4DFF)
val WardrobeAccent = Color(0xFF00D4FF)
val WardrobePinkAccent = Color(0xFFFF5FA2)

val TextDark = Color(0xFF1E293B)
val TextLight = Color(0xFF64748B)

val GlassBase = Color(0x3BFFFFFF) // High transparency White
val GlassBorder = Color(0x2BFFFFFF) // Subtle White Glass Outline
val CardSurface = Color(0xFFFFFFFF)
val DividerColor = Color(0x1F7C4DFF)

