package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import com.example.ui.components.MeshGradientBackground
import com.example.ui.viewmodel.AuthState
import com.example.ui.viewmodel.AuthViewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val EaseInOutSine = Easing { fraction ->
    -(cos(PI * fraction) - 1f).toFloat() / 2f
}

@Composable
fun AuthScreensHandler(
    viewModel: AuthViewModel,
    onAuthSuccess: (email: String, name: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val authState by viewModel.authState.collectAsState()
    val errorMsg by viewModel.errorState.collectAsState()
    val recoveryMsg by viewModel.verificationSuccess.collectAsState()

    MeshGradientBackground(modifier = modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(
                targetState = authState,
                animationSpec = spring(stiffness = Spring.StiffnessLow),
                label = "auth_crossfade"
            ) { state ->
                when (state) {
                    is AuthState.Welcome -> WelcomeScreen(viewModel)
                    is AuthState.Login -> LoginScreen(viewModel)
                    is AuthState.Signup -> SignupScreen(viewModel)
                    is AuthState.ForgotPassword -> ForgotPasswordScreen(viewModel)
                    is AuthState.Loading -> AuthLoadingScreen()
                    is AuthState.LoggedIn -> {
                        LaunchedEffect(state) {
                            onAuthSuccess(state.email, state.displayName)
                        }
                        Box(modifier = Modifier.fillMaxSize()) // Empty container while redirecting
                    }
                    is AuthState.Error -> {
                        // Safe state redirection
                    }
                }
            }

            // High-end dynamic popups for input warning/error notices
            if (errorMsg != null) {
                GlassPopups(
                    message = errorMsg!!,
                    isError = true,
                    onDismiss = { viewModel.dismissError() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 32.dp, start = 24.dp, end = 24.dp)
                )
            }

            // High-end discovery notices
            if (recoveryMsg != null) {
                GlassPopups(
                    message = recoveryMsg!!,
                    isError = false,
                    onDismiss = { viewModel.dismissVerification() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 32.dp, start = 24.dp, end = 24.dp)
                )
            }
        }
    }
}

@Composable
fun WelcomeScreen(viewModel: AuthViewModel) {
    val infiniteTransition = rememberInfiniteTransition(label = "welcome_loops")
    val floatY by infiniteTransition.animateFloat(
        initialValue = -12f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ), label = "float_welcome"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 28.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(40.dp))

        // Large 3D Glass-Look Floating Logo Block
        Box(
            modifier = Modifier
                .size(160.dp)
                .offset(y = floatY.dp)
                .drawBehind {
                    val r = size.width / 2f
                    // Soft bottom drop shadow
                    drawCircle(
                        color = Color(0xFF1E2845).copy(alpha = 0.04f),
                        radius = r * 1.1f,
                        center = Offset(r, r + 8f)
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cen = Offset(size.width / 2f, size.height / 2f)
                val rad = size.width * 0.42f

                // Underlay colorful aura
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF4285F4).copy(alpha = 0.45f),
                            Color(0xFF00D4FF).copy(alpha = 0.25f),
                            Color.Transparent
                        ),
                        center = cen,
                        radius = rad * 1.5f
                    ),
                    radius = rad * 1.5f
                )

                // Translucent white capsule orb base
                drawCircle(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.85f),
                            Color(0xFFE6EFFF).copy(alpha = 0.45f)
                        ),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, size.height)
                    ),
                    radius = rad,
                    center = cen
                )

                // Fine outline highlighting the orb
                drawCircle(
                    color = Color.White.copy(alpha = 0.65f),
                    radius = rad,
                    center = cen,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // Gemini star paths representing internal fashion design core
                val starSize = rad * 0.60f
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(cen.x, cen.y - starSize)
                    quadraticTo(cen.x, cen.y, cen.x + starSize, cen.y)
                    quadraticTo(cen.x, cen.y, cen.x, cen.y + starSize)
                    quadraticTo(cen.x, cen.y, cen.x - starSize, cen.y)
                    quadraticTo(cen.x, cen.y, cen.x, cen.y - starSize)
                    close()
                }

                drawPath(
                    path = path,
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0xFF4285F4), Color(0xFF7C4DFF), Color(0xFFFF5FA2)),
                        start = Offset(cen.x - starSize, cen.y - starSize),
                        end = Offset(cen.x + starSize, cen.y + starSize)
                    )
                )
            }

            // Overlay absolute luxury minimal coat hanger inside
            Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = "AI Stylist",
                tint = Color.White,
                modifier = Modifier.size(38.dp)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = "WARDROBE AI",
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Bold,
            fontSize = 32.sp,
            letterSpacing = 2.sp,
            color = Color(0xFF13141C),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Your premium companion for digital dressing, style optimization, and smart cataloging built on Google Gemini.",
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Normal,
            fontSize = 14.sp,
            lineHeight = 21.sp,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(44.dp))

        // Unified login controllers
        GlassButton(
            text = "Continue with Email",
            icon = Icons.Outlined.Email,
            onClick = { viewModel.navigateTo(AuthState.Login) },
            isPrimary = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("continue_email_button")
        )

        Spacer(modifier = Modifier.height(14.dp))

        GlassButton(
            text = "Continue with Google",
            icon = Icons.Filled.AccountCircle,
            onClick = { viewModel.loginWithGoogle() },
            isPrimary = false,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("continue_google_button")
        )

        Spacer(modifier = Modifier.height(44.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "New stylist?",
                color = Color(0xFF64748B),
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Join now",
                color = Color(0xFF4285F4),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable { viewModel.navigateTo(AuthState.Signup) }
                    .padding(vertical = 4.dp, horizontal = 6.dp)
                    .testTag("go_register_text")
            )
        }

        Spacer(modifier = Modifier.height(18.dp))
    }
}

@Composable
fun LoginScreen(viewModel: AuthViewModel) {
    val email by viewModel.loginEmail.collectAsState()
    val password by viewModel.loginPassword.collectAsState()

    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Back navigation button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.25f))
                    .border(1.dp, Color.White.copy(alpha = 0.45f), CircleShape)
                    .clickable { viewModel.navigateTo(AuthState.Welcome) }
                    .testTag("back_to_welcome"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF13141C)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "Welcome Back",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Color(0xFF13141C)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // High fidelity translucent card housing credentials input
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(elevation = 12.dp, shape = RoundedCornerShape(24.dp), clip = false)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White.copy(alpha = 0.35f))
                .border(1.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Text(
                text = "Stylist Credentials",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF13141C)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Sign in to access your digital apparel.",
                fontSize = 13.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(20.dp))

            GlassTextField(
                value = email,
                onValueChange = { viewModel.loginEmail.value = it },
                label = "Email Address",
                placeholder = "chic@wardrobe.ai",
                icon = Icons.Outlined.Email,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_email_input")
            )

            Spacer(modifier = Modifier.height(14.dp))

            GlassTextField(
                value = password,
                onValueChange = { viewModel.loginPassword.value = it },
                label = "Password",
                placeholder = "••••••••",
                icon = Icons.Outlined.Lock,
                isPassword = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                        keyboardController?.hide()
                        viewModel.loginWithEmail()
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_password_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Forgot Password Link
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.CenterEnd
            ) {
                Text(
                    text = "Forgot Style Code?",
                    color = Color(0xFF4285F4),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .clickable { viewModel.navigateTo(AuthState.ForgotPassword) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                        .testTag("forgot_password_link")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            GlassButton(
                text = "Enter Studio",
                icon = Icons.Filled.Login,
                isPrimary = true,
                onClick = {
                    focusManager.clearFocus()
                    keyboardController?.hide()
                    viewModel.loginWithEmail()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_submit_button")
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Or, sign in directly using Google",
            color = Color(0xFF64748B),
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        GlassButton(
            text = "Sign in with Google",
            icon = Icons.Filled.AccountCircle,
            onClick = { viewModel.loginWithGoogle() },
            isPrimary = false,
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .testTag("google_login_alternative")
        )

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Need an account? ", color = Color(0xFF64748B), fontSize = 14.sp)
            Text(
                text = "Register Studio",
                color = Color(0xFF7C4DFF),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable { viewModel.navigateTo(AuthState.Signup) }
                    .padding(vertical = 4.dp, horizontal = 4.dp)
                    .testTag("go_to_signup")
            )
        }
    }
}

@Composable
fun SignupScreen(viewModel: AuthViewModel) {
    val name by viewModel.signupName.collectAsState()
    val email by viewModel.signupEmail.collectAsState()
    val password by viewModel.signupPassword.collectAsState()
    val confirm by viewModel.signupConfirmPassword.collectAsState()

    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.25f))
                    .border(1.dp, Color.White.copy(alpha = 0.45f), CircleShape)
                    .clickable { viewModel.navigateTo(AuthState.Welcome) }
                    .testTag("back_from_signup"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF13141C)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "Register Studio",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Color(0xFF13141C)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(elevation = 12.dp, shape = RoundedCornerShape(24.dp), clip = false)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White.copy(alpha = 0.35f))
                .border(1.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Text(
                text = "Create Wardrobe Profile",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF13141C)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Establish your secure local/cloud locker.",
                fontSize = 13.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(18.dp))

            GlassTextField(
                value = name,
                onValueChange = { viewModel.signupName.value = it },
                label = "Full Name",
                placeholder = "Valen Garment",
                icon = Icons.Outlined.Person,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signup_name_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            GlassTextField(
                value = email,
                onValueChange = { viewModel.signupEmail.value = it },
                label = "Email Address",
                placeholder = "stylist@wardrobe.ai",
                icon = Icons.Outlined.Email,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signup_email_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            GlassTextField(
                value = password,
                onValueChange = { viewModel.signupPassword.value = it },
                label = "Style Password",
                placeholder = "6+ characters",
                icon = Icons.Outlined.Lock,
                isPassword = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signup_password_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            GlassTextField(
                value = confirm,
                onValueChange = { viewModel.signupConfirmPassword.value = it },
                label = "Confirm Password",
                placeholder = "Re-enter style password",
                icon = Icons.Outlined.Verified,
                isPassword = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                        keyboardController?.hide()
                        viewModel.signUpWithEmail()
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signup_confirm_password")
            )

            Spacer(modifier = Modifier.height(18.dp))

            GlassButton(
                text = "Register Portfolio",
                icon = Icons.Filled.AppRegistration,
                isPrimary = true,
                onClick = {
                    focusManager.clearFocus()
                    keyboardController?.hide()
                    viewModel.signUpWithEmail()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signup_submit_button")
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Already registered? ", color = Color(0xFF64748B), fontSize = 14.sp)
            Text(
                text = "Sign In",
                color = Color(0xFF4285F4),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable { viewModel.navigateTo(AuthState.Login) }
                    .padding(vertical = 4.dp, horizontal = 4.dp)
                    .testTag("go_to_login")
            )
        }
    }
}

@Composable
fun ForgotPasswordScreen(viewModel: AuthViewModel) {
    val email by viewModel.forgotEmail.collectAsState()
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.25f))
                    .border(1.dp, Color.White.copy(alpha = 0.45f), CircleShape)
                    .clickable { viewModel.navigateTo(AuthState.Login) }
                    .testTag("back_to_login"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF13141C)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "Recover Password",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Color(0xFF13141C)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(elevation = 12.dp, shape = RoundedCornerShape(24.dp), clip = false)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White.copy(alpha = 0.35f))
                .border(1.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Text(
                text = "Send Style recovery",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF13141C)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Enter registered email to deliver a secure password reset link.",
                fontSize = 13.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(20.dp))

            GlassTextField(
                value = email,
                onValueChange = { viewModel.forgotEmail.value = it },
                label = "Registered Email",
                placeholder = "chic@wardrobe.ai",
                icon = Icons.Outlined.Email,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                        keyboardController?.hide()
                        viewModel.sendForgotPasswordLink()
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("forgot_email_input")
            )

            Spacer(modifier = Modifier.height(20.dp))

            GlassButton(
                text = "Dispatch Link",
                icon = Icons.Filled.Send,
                isPrimary = true,
                onClick = {
                    focusManager.clearFocus()
                    keyboardController?.hide()
                    viewModel.sendForgotPasswordLink()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("forgot_submit_button")
            )
        }
    }
}

@Composable
fun AuthLoadingScreen() {
    val infinite = rememberInfiniteTransition(label = "loader_loops")
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = "loader_spin"
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .scale(rotation / 360f * 0.4f + 0.8f)
                .drawBehind {
                    drawCircle(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color(0xFF4285F4),
                                Color(0xFF7C4DFF),
                                Color(0xFFFF5FA2),
                                Color(0xFF00D4FF),
                                Color(0xFF4285F4)
                            )
                        ),
                        style = Stroke(width = 4.dp.toPx())
                    )
                }
        )
        Spacer(modifier = Modifier.height(18.dp))
        Text(
            text = "Analyzing Outfit Ecosystem...",
            fontWeight = FontWeight.Medium,
            fontSize = 14.sp,
            color = Color(0xFF13141C)
        )
    }
}

// PREMIUM COMPONENTS //

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlassTextField(
    value: String,
    onValueChange: (value: String) -> Unit,
    label: String,
    placeholder: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default
) {
    var isVisible by remember { mutableStateOf(false) }

    Column(modifier = modifier) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1E2845),
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )

        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .shadow(3.dp, shape = RoundedCornerShape(14.dp), clip = false)
                .background(Color.White.copy(alpha = 0.40f), shape = RoundedCornerShape(14.dp)),
            placeholder = {
                Text(
                    text = placeholder,
                    color = Color(0xFF94A3B8),
                    fontSize = 14.sp
                )
            },
            keyboardOptions = keyboardOptions,
            keyboardActions = keyboardActions,
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF4285F4),
                unfocusedBorderColor = Color.White.copy(alpha = 0.55f),
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedTextColor = Color(0xFF1E2845),
                unfocusedTextColor = Color(0xFF1E2845),
                cursorColor = Color(0xFF4285F4)
            ),
            visualTransformation = if (isPassword && !isVisible) PasswordVisualTransformation() else VisualTransformation.None,
            leadingIcon = {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFF64748B),
                    modifier = Modifier.size(20.dp)
                )
            },
            trailingIcon = {
                if (isPassword) {
                    val eyeIcon = if (isVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    IconButton(
                        onClick = { isVisible = !isVisible },
                        modifier = Modifier.size(48.dp) // Accessibility guideline touch target
                    ) {
                        Icon(
                            imageVector = eyeIcon,
                            contentDescription = "Toggle password visibility",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        )
    }
}

@Composable
fun GlassButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isPrimary: Boolean = true
) {
    if (isPrimary) {
        // High luxury Primary button with colorful mesh glow
        Box(
            modifier = modifier
                .height(54.dp)
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(16.dp), clip = false)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0xFF4285F4), Color(0xFF7C4DFF))
                    )
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = Color.White),
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = text,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }
    } else {
        // High luxury Frosted Secondary Glass button
        Box(
            modifier = modifier
                .height(54.dp)
                .shadow(elevation = 3.dp, shape = RoundedCornerShape(16.dp), clip = false)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.35f))
                .border(
                    width = 1.25.dp,
                    color = Color.White.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(16.dp)
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = Color(0xFF4285F4).copy(alpha = 0.15f)),
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFF4285F4),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = text,
                    color = Color(0xFF1E2845),
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

@Composable
fun GlassPopups(
    message: String,
    isError: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(message) {
        delay(4000)
        onDismiss()
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .shadow(12.dp, shape = RoundedCornerShape(18.dp), clip = false)
            .clip(RoundedCornerShape(18.dp))
            .background(
                if (isError) Color(0xFFFFF2F4).copy(alpha = 0.85f) else Color(0xFFE6FDFC).copy(alpha = 0.85f)
            )
            .border(
                width = 1.dp,
                color = if (isError) Color(0xFFFFD1D6).copy(alpha = 0.9f) else Color(0xFFBCFAEE).copy(alpha = 0.9f),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onDismiss)
            .padding(vertical = 14.dp, horizontal = 18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(0.9f)
            ) {
                Icon(
                    imageVector = if (isError) Icons.Filled.Error else Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = if (isError) Color(0xFFE53935) else Color(0xFF00B0FF),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = message,
                    color = Color(0xFF1E2845),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Close popup",
                    tint = Color(0xFF64748B),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
