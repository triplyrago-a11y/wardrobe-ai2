package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.WardrobeBackground
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MeshGradientBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mesh_mesh")

    // Slow, fluid oscillations for centers of our soft colorful blobs
    val angle1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle_1"
    )

    val angle2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(22000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle_2"
    )

    val angle3 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(28000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle_3"
    )

    val angle4 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(32000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle_4"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(WardrobeBackground)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            if (width == 0f || height == 0f) return@Canvas

            // Dynamic oscillating positions
            val center1 = Offset(
                x = width * 0.25f + width * 0.15f * cos(angle1),
                y = height * 0.25f + height * 0.12f * sin(angle1)
            )
            val center2 = Offset(
                x = width * 0.75f + width * 0.12f * sin(angle2),
                y = height * 0.35f + height * 0.15f * cos(angle2)
            )
            val center3 = Offset(
                x = width * 0.30f + width * 0.18f * sin(angle3),
                y = height * 0.75f + height * 0.10f * cos(angle3)
            )
            val center4 = Offset(
                x = width * 0.70f + width * 0.14f * cos(angle4),
                y = height * 0.80f + height * 0.16f * sin(angle4)
            )

            // Drawing very soft ambient colored blobs with extremely low opacity
            // Color 1: Soft Blue
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF4285F4).copy(alpha = 0.08f), Color.Transparent),
                    center = center1,
                    radius = width * 0.65f
                ),
                center = center1,
                radius = width * 0.65f
            )

            // Color 2: Soft Purple
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF7C4DFF).copy(alpha = 0.07f), Color.Transparent),
                    center = center2,
                    radius = width * 0.60f
                ),
                center = center2,
                radius = width * 0.60f
            )

            // Color 3: Soft Pink
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFFF5FA2).copy(alpha = 0.06f), Color.Transparent),
                    center = center3,
                    radius = width * 0.70f
                ),
                center = center3,
                radius = width * 0.70f
            )

            // Color 4: Soft Cyan
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF00D4FF).copy(alpha = 0.08f), Color.Transparent),
                    center = center4,
                    radius = width * 0.55f
                ),
                center = center4,
                radius = width * 0.55f
            )
        }

        content()
    }
}
