package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface AuthState {
    object Welcome : AuthState
    object Login : AuthState
    object Signup : AuthState
    object ForgotPassword : AuthState
    object Loading : AuthState
    data class LoggedIn(val email: String, val displayName: String, val isMock: Boolean) : AuthState
    data class Error(val message: String, val returnToState: AuthState) : AuthState
}

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val sharedPrefs = application.getSharedPreferences("wardrobe_auth_prefs", Context.MODE_PRIVATE)

    private val _authState = MutableStateFlow<AuthState>(AuthState.Welcome)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _errorState = MutableStateFlow<String?>(null)
    val errorState: StateFlow<String?> = _errorState.asStateFlow()

    private val _verificationSuccess = MutableStateFlow<String?>(null)
    val verificationSuccess: StateFlow<String?> = _verificationSuccess.asStateFlow()

    // Cache current credentials during interactions
    val signupEmail = MutableStateFlow("")
    val signupPassword = MutableStateFlow("")
    val signupConfirmPassword = MutableStateFlow("")
    val signupName = MutableStateFlow("")

    val loginEmail = MutableStateFlow("")
    val loginPassword = MutableStateFlow("")

    val forgotEmail = MutableStateFlow("")

    // Firebase state
    private var firebaseAuth: FirebaseAuth? = null

    init {
        // Safe check for Firebase configuration matching guidelines to prevent emulator crashes
        try {
            if (FirebaseApp.getApps(application).isNotEmpty()) {
                firebaseAuth = FirebaseAuth.getInstance()
                val currentFirebaseUser = firebaseAuth?.currentUser
                if (currentFirebaseUser != null) {
                    _authState.value = AuthState.LoggedIn(
                        email = currentFirebaseUser.email ?: "",
                        displayName = currentFirebaseUser.displayName ?: "Style Icon",
                        isMock = false
                    )
                } else {
                    checkLocalPersistence()
                }
            } else {
                checkLocalPersistence()
            }
        } catch (e: Exception) {
            checkLocalPersistence()
        }
    }

    private fun checkLocalPersistence() {
        val email = sharedPrefs.getString("logged_in_email", null)
        val name = sharedPrefs.getString("logged_in_name", null)
        if (email != null) {
            _authState.value = AuthState.LoggedIn(
                email = email,
                displayName = name ?: "Fashion Fanatic",
                isMock = true
            )
        } else {
            _authState.value = AuthState.Welcome
        }
    }

    fun navigateTo(state: AuthState) {
        _errorState.value = null
        _verificationSuccess.value = null
        _authState.value = state
    }

    fun loginWithEmail() {
        val email = loginEmail.value.trim()
        val password = loginPassword.value

        if (email.isEmpty() || password.isEmpty()) {
            _errorState.value = "Please fill in all credentials."
            return
        }

        if (!email.contains("@") || !email.contains(".")) {
            _errorState.value = "Invalid email formatting."
            return
        }

        _authState.value = AuthState.Loading
        viewModelScope.launch {
            delay(1200) // Beautiful organic glass transition delay
            
            // Try actual Firebase Auth first
            var firebaseSucceeded = false
            try {
                if (firebaseAuth != null) {
                    firebaseAuth?.signInWithEmailAndPassword(email, password)
                        ?.addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val user = firebaseAuth?.currentUser
                                _authState.value = AuthState.LoggedIn(
                                    email = user?.email ?: email,
                                    displayName = user?.displayName ?: "Style Icon",
                                    isMock = false
                                )
                            }
                        }
                    firebaseSucceeded = true
                }
            } catch (e: Exception) {
                // Fail silently to trigger local sandbox fallback
            }

            if (!firebaseSucceeded) {
                // High-End persistent Sandbox validation
                val registeredPassword = sharedPrefs.getString("user_pwd_$email", null)
                if (registeredPassword == null) {
                    // Pre-registered defaults for instant testing
                    if (email == "chic@wardrobe.ai" && password == "stylish") {
                        sharedPrefs.edit()
                            .putString("logged_in_email", email)
                            .putString("logged_in_name", "Chic Stylist")
                            .apply()
                        _authState.value = AuthState.LoggedIn(email, "Chic Stylist", isMock = true)
                    } else {
                         _authState.value = AuthState.Welcome
                         _errorState.value = "Account not found. Feel free to register!"
                         navigateTo(AuthState.Login)
                    }
                } else if (registeredPassword != password) {
                    _authState.value = AuthState.Login
                    _errorState.value = "Incorrect password. Try again."
                } else {
                    val name = sharedPrefs.getString("user_name_$email", "Trendsetter") ?: "Trendsetter"
                    sharedPrefs.edit()
                        .putString("logged_in_email", email)
                        .putString("logged_in_name", name)
                        .apply()
                    _authState.value = AuthState.LoggedIn(email, name, isMock = true)
                }
            }
        }
    }

    fun signUpWithEmail() {
        val email = signupEmail.value.trim()
        val password = signupPassword.value
        val confirm = signupConfirmPassword.value
        val name = signupName.value.trim()

        if (email.isEmpty() || password.isEmpty() || name.isEmpty()) {
            _errorState.value = "Please complete all fields."
            return
        }

        if (!email.contains("@") || !email.contains(".")) {
            _errorState.value = "Please enter a valid email address."
            return
        }

        if (password.length < 6) {
            _errorState.value = "Password must be at least 6 characters."
            return
        }

        if (password != confirm) {
            _errorState.value = "Passwords do not match."
            return
        }

        _authState.value = AuthState.Loading
        viewModelScope.launch {
            delay(1500) // Premium cinematic glass effect

            var firebaseSucceeded = false
            try {
                if (firebaseAuth != null) {
                    firebaseAuth?.createUserWithEmailAndPassword(email, password)
                        ?.addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val user = firebaseAuth?.currentUser
                                _authState.value = AuthState.LoggedIn(
                                    email = user?.email ?: email,
                                    displayName = name,
                                    isMock = false
                                )
                            }
                        }
                    firebaseSucceeded = true
                }
            } catch (e: Exception) {
                // Fail-safe to offline sandbox
            }

            if (!firebaseSucceeded) {
                // Sandbox registration persistence
                sharedPrefs.edit()
                    .putString("user_pwd_$email", password)
                    .putString("user_name_$email", name)
                    .putString("logged_in_email", email)
                    .putString("logged_in_name", name)
                    .apply()
                _authState.value = AuthState.LoggedIn(email, name, isMock = true)
            }
        }
    }

    fun sendForgotPasswordLink() {
        val email = forgotEmail.value.trim()
        if (email.isEmpty() || !email.contains("@")) {
            _errorState.value = "Please enter a valid email."
            return
        }

        _authState.value = AuthState.Loading
        viewModelScope.launch {
            delay(1200)

            var firebaseSucceeded = false
            try {
                if (firebaseAuth != null) {
                    firebaseAuth?.sendPasswordResetEmail(email)
                    firebaseSucceeded = true
                }
            } catch (e: Exception) {
                // Fail-safe
            }

            _verificationSuccess.value = "A recovery link was dispatched to $email"
            _authState.value = AuthState.Login
        }
    }

    fun loginWithGoogle() {
        _authState.value = AuthState.Loading
        viewModelScope.launch {
            delay(1800) // Simulates elegant Google account choosing sequence
            
            // Log in as high premium Google User
            val googleEmail = "google.stylist@gmail.com"
            val googleName = "Gemini Stylist"
            
            sharedPrefs.edit()
                .putString("logged_in_email", googleEmail)
                .putString("logged_in_name", googleName)
                .apply()

            _authState.value = AuthState.LoggedIn(
                email = googleEmail,
                displayName = googleName,
                isMock = true
            )
        }
    }

    fun logOut() {
        try {
            firebaseAuth?.signOut()
        } catch (e: Exception) {
            // Safe
        }
        sharedPrefs.edit()
            .remove("logged_in_email")
            .remove("logged_in_name")
            .apply()
        _authState.value = AuthState.Welcome
    }

    fun dismissError() {
        _errorState.value = null
    }

    fun dismissVerification() {
        _verificationSuccess.value = null
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return AuthViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
