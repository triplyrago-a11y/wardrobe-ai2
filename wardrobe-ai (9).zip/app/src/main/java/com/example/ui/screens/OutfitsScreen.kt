package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.WardrobeItem
import com.example.ui.components.FloatingLiquidGlassCard
import com.example.ui.components.LiquidGlassCard
import com.example.ui.viewmodel.WardrobeViewModel

@Composable
fun OutfitsScreen(
    viewModel: WardrobeViewModel,
    modifier: Modifier = Modifier
) {
    val items by viewModel.allWardrobeItems.collectAsState()
    
    val tops = items.filter { it.category == "Tops" }
    val bottoms = items.filter { it.category == "Bottoms" }
    val outerwear = items.filter { it.category == "Outerwear" }
    val shoes = items.filter { it.category == "Shoes" }

    var selectedTop by remember { mutableStateOf<WardrobeItem?>(null) }
    var selectedBottom by remember { mutableStateOf<WardrobeItem?>(null) }
    var selectedJackets by remember { mutableStateOf<WardrobeItem?>(null) }

    // Preset Outfits mock to look gorgeous
    val presetOutfits = listOf(
        PresetOutfit("Quiet Luxury Chic", "Classic tailored blazer paired with silk blend shirt and straight wool trouser.", "#CAD2C5"),
        PresetOutfit("Weekend Slouch", "Oversized cotton crewneck paired with washed relaxed line canvas pant.", "#E9D8A6"),
        PresetOutfit("Metropolitan Smart", "Minimalist mock neck heavy wool vest with crisp micro-pleat pants.", "#94D2BD")
    )

    // Set initial choices if items are loaded
    LaunchedEffect(items) {
        if (selectedTop == null && tops.isNotEmpty()) selectedTop = tops.first()
        if (selectedBottom == null && bottoms.isNotEmpty()) selectedBottom = bottoms.first()
        if (selectedJackets == null && outerwear.isNotEmpty()) selectedJackets = outerwear.first()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.statusBarsPadding())
        Spacer(modifier = Modifier.height(20.dp))

        // Screen Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "WARDROBE AI / ENSEMBLES",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        color = com.example.ui.theme.TextLight
                    )
                )
                Text(
                    text = "Outfit Mixer",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = com.example.ui.theme.TextDark
                    )
                )
            }

            // Quick Create indicator
            IconButton(
                onClick = {
                    // Random mix
                    if (tops.isNotEmpty()) selectedTop = tops.random()
                    if (bottoms.isNotEmpty()) selectedBottom = bottoms.random()
                    if (outerwear.isNotEmpty()) selectedJackets = outerwear.random()
                },
                modifier = Modifier
                    .size(40.dp)
                    .background(Color.White.copy(alpha = 0.5f), CircleShape)
                    .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Casino,
                    contentDescription = "Random Shuffle Outfit",
                    tint = com.example.ui.theme.TextDark,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Preset curated coordinates
        Text(
            text = "CURATED COMBINATIONS",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            color = com.example.ui.theme.TextLight,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            presetOutfits.forEach { preset ->
                Box(
                    modifier = Modifier
                        .width(220.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.White.copy(alpha = 0.5f))
                        .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(android.graphics.Color.parseColor(preset.accentColor)).copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Checkroom,
                                contentDescription = null,
                                tint = Color(android.graphics.Color.parseColor(preset.accentColor)),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = preset.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = com.example.ui.theme.TextDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = preset.desc,
                            fontSize = 12.sp,
                            color = com.example.ui.theme.TextLight,
                            lineHeight = 16.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. Interactive mixer canvas
        Text(
            text = "INTERACTIVE STYLING BOARD",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            color = com.example.ui.theme.TextLight,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        FloatingLiquidGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 120.dp)
        ) {
            Column(modifier = Modifier.padding(4.dp)) {
                // Top
                MixerRow(
                    label = "TOP PIECE",
                    selectedItem = selectedTop,
                    itemsList = tops,
                    onSelected = { selectedTop = it }
                )

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = Color.LightGray.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(16.dp))

                // Bottom
                MixerRow(
                    label = "BOTTOM PIECE",
                    selectedItem = selectedBottom,
                    itemsList = bottoms,
                    onSelected = { selectedBottom = it }
                )

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = Color.LightGray.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(16.dp))

                // Jacket
                MixerRow(
                    label = "JACKET / LAYERING",
                    selectedItem = selectedJackets,
                    itemsList = outerwear,
                    onSelected = { selectedJackets = it }
                )
            }
        }
    }
}

@Composable
fun MixerRow(
    label: String,
    selectedItem: WardrobeItem?,
    itemsList: List<WardrobeItem>,
    onSelected: (WardrobeItem) -> Unit
) {
    Column {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = com.example.ui.theme.TextLight,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (itemsList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.2f))
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = "No items scanned in this category yet.",
                    fontSize = 12.sp,
                    color = com.example.ui.theme.TextLight
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsList.forEach { item ->
                    val isChecked = selectedItem?.id == item.id
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                color = if (isChecked) Color(0xFF4285F4).copy(alpha = 0.12f) else Color.White.copy(alpha = 0.35f)
                            )
                            .border(
                                width = if (isChecked) 1.5.dp else 1.dp,
                                color = if (isChecked) Color(0xFF4285F4) else Color.LightGray.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { onSelected(item) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(android.graphics.Color.parseColor(item.colorHex)))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item.name,
                                fontSize = 13.sp,
                                fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Medium,
                                color = if (isChecked) Color(0xFF4285F4) else com.example.ui.theme.TextDark
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class PresetOutfit(
    val name: String,
    val desc: String,
    val accentColor: String
)
