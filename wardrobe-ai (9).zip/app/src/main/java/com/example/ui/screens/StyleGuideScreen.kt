package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Checkroom
import androidx.compose.material.icons.outlined.ColorLens
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import com.example.ui.components.FloatingLiquidGlassCard
import com.example.ui.components.LiquidGlassCard
import com.example.ui.viewmodel.WardrobeViewModel

import androidx.compose.material.icons.filled.ExitToApp

@Composable
fun StyleGuideScreen(
    viewModel: WardrobeViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activePersona by viewModel.stylePersona.collectAsState()
    val activeSeason by viewModel.seasonTone.collectAsState()

    val styleAesthetics = listOf("Quiet Luxury", "Minimal Classic", "Streetwear Edge", "Artistic Indie")
    val seasonalColors = listOf(
        "Cool Winter (High Contrast)",
        "Warm Autumn (Earthy & Rich)",
        "Bright Spring (Vibrant & Warm)",
        "Muted Summer (Soft Tonal)"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.statusBarsPadding())
        Spacer(modifier = Modifier.height(20.dp))

        // Screen Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "WARDROBE AI / IDENTITY",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        color = com.example.ui.theme.TextLight
                    )
                )
                Text(
                    text = "Style Profile",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = com.example.ui.theme.TextDark
                    )
                )
            }

            // Profile Avatar Decor
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color.White, CircleShape)
                    .background(Color.White.copy(alpha = 0.2f))
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFF5FA2),
                                    Color(0xFF00D4FF)
                                )
                            )
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 1. Interactive persona selector
        Text(
            text = "SIGNATURE ESTHETIC",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            color = com.example.ui.theme.TextLight,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            styleAesthetics.forEach { aesthetic ->
                val isSelected = activePersona == aesthetic
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.5f)
                        )
                        .border(
                            width = 1.dp,
                            color = if (isSelected) Color.Transparent else Color.LightGray.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { viewModel.setStylePersona(aesthetic) }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.Star,
                            contentDescription = null,
                            tint = if (isSelected) Color.White else Color(0xFF7C4DFF).copy(alpha = 0.5f),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = aesthetic,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else com.example.ui.theme.TextDark
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. Season tone selector
        Text(
            text = "SEASONAL COLOR SCHEME",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            color = com.example.ui.theme.TextLight,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Column(modifier = Modifier.fillMaxWidth()) {
            seasonalColors.forEach { season ->
                val isSelected = activeSeason == season
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            color = if (isSelected) Color(0xFF7C4DFF).copy(alpha = 0.08f) else Color.White.copy(alpha = 0.5f)
                        )
                        .border(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) Color(0xFF7C4DFF) else Color.LightGray.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(18.dp)
                        )
                        .clickable { viewModel.setSeasonTone(season) }
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = null,
                                tint = if (isSelected) Color(0xFF7C4DFF) else com.example.ui.theme.TextLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = season,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 14.sp,
                                color = com.example.ui.theme.TextDark
                            )
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Selected",
                                tint = Color(0xFF7C4DFF),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 3. Dynamic styling tips card reflecting selections
        Text(
            text = "STYLIST INSIGHTS",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            color = com.example.ui.theme.TextLight,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        FloatingLiquidGlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color(0xFF00D4FF),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Your $activePersona Blueprint",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = com.example.ui.theme.TextDark
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val tips = getCustomStylistTips(activePersona, activeSeason)
                Text(
                    text = tips.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = com.example.ui.theme.TextDark,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Divider(color = com.example.ui.theme.DividerColor)

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Core Palette Directions",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Render matching tiny color chip circles
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    tips.paletteColors.forEach { (colorName, hexStr) ->
                        val chipColor = Color(android.graphics.Color.parseColor(hexStr))
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(chipColor)
                                .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Suggested Coordinates to Look For:",
                    style = MaterialTheme.typography.labelSmall,
                    color = com.example.ui.theme.TextLight,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                tips.suggestedPieces.forEach { piece ->
                    Row(
                        modifier = Modifier.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Checkroom,
                            contentDescription = null,
                            tint = Color(0xFF7C4DFF),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = piece,
                            fontSize = 12.sp,
                            color = com.example.ui.theme.TextDark
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Premium Liquid Glass Logout Button
        Button(
            onClick = onLogout,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("logout_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White.copy(alpha = 0.25f),
                contentColor = Color(0xFFE53935)
            ),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.45f))
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = "Logout",
                    tint = Color(0xFFE53935),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Sign Out of Studio",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(100.dp))
    }
}

class StylistGuideTips(
    val summary: String,
    val paletteColors: List<Pair<String, String>>,
    val suggestedPieces: List<String>
)

fun getCustomStylistTips(persona: String, season: String): StylistGuideTips {
    return when (persona) {
        "Quiet Luxury" -> {
            StylistGuideTips(
                summary = "The hallmark of Quiet Luxury is exceptional, drape-focused architecture with unbranded simplicity. Match tailored silhouettes with high-quality materials such as cashmere, French linen, and silk. Stick to monochromatic layer layouts inside the $season schema.",
                paletteColors = listOf(
                    Pair("Oatmeal", "#E5D9C4"),
                    Pair("Camel", "#C19A6B"),
                    Pair("Midnight Black", "#1A1A22"),
                    Pair("Chalk White", "#FAF9F6")
                ),
                suggestedPieces = listOf(
                    "Cashmere V-neck Knit Sweater",
                    "Wool Tailored Long Overcoat",
                    "Italian Soft Calfskin Loafers"
                )
            )
        }
        "Minimal Classic" -> {
            StylistGuideTips(
                summary = "Ultra-refined basics focusing on symmetric clean lines. Avoid visual distractions and choose clothes with highly reusable, structural utility. Use the $season color palette to layer high-contrast tops and relaxed, fluid-fitting bottoms.",
                paletteColors = listOf(
                    Pair("Navy Slate", "#2B3A4A"),
                    Pair("Ecru White", "#F5F5DC"),
                    Pair("Soft French Grey", "#A9B7C6"),
                    Pair("Charcoal", "#24252B")
                ),
                suggestedPieces = listOf(
                    "Organic Cotton Heavy Tee",
                    "Refined Selvedge Denim Pants",
                    "Structured Crisp Cotton Trench"
                )
            )
        }
        "Streetwear Edge" -> {
            StylistGuideTips(
                summary = "Asymmetrical structured layering, oversized proportions, and dramatic silhouettes. Pair sleek relaxed cargo lines with dynamic, heavy-knit boxy sweaters. Perfect for infusing high-contrast style accents into your capsule.",
                paletteColors = listOf(
                    Pair("Sage Wash", "#879883"),
                    Pair("Rust Terracotta", "#C05230"),
                    Pair("Midnight Dust", "#121215"),
                    Pair("Sky Breeze", "#C9DDFC")
                ),
                suggestedPieces = listOf(
                    "Boxy Heavyweight Drop Tee",
                    "Unstructured Wide Utility Cargos",
                    "Chunky Platform Minimalist Sneakers"
                )
            )
        }
        else -> { // Artistic Indie
            StylistGuideTips(
                summary = "Focuses on rich textural depth, eclectic retro tailoring, and expressive accessory layers. Curate visual interest by combining knitted sweater vests with tapered cropped trousers in contrasting organic earthy tones.",
                paletteColors = listOf(
                    Pair("Olive Moss", "#6B8E23"),
                    Pair("Copper Brown", "#B87333"),
                    Pair("Warm Vanilla", "#FFFCE8"),
                    Pair("Muted Aubergine", "#581845")
                ),
                suggestedPieces = listOf(
                    "Ribbed Chunky Cable Cardigan",
                    "Pleated Wool Tapered Trousers",
                    "Polished Leather Derby Shoes"
                )
            )
        }
    }
}
