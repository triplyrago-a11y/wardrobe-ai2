package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Checkroom
import androidx.compose.material.icons.outlined.CloudSync
import androidx.compose.material.icons.outlined.ColorLens
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FloatingLiquidGlassCard
import com.example.ui.components.LiquidGlassCard
import com.example.ui.viewmodel.WardrobeViewModel

@Composable
fun ProfileScreen(
    viewModel: WardrobeViewModel,
    modifier: Modifier = Modifier
) {
    val items by viewModel.allWardrobeItems.collectAsState()
    val activePersona by viewModel.stylePersona.collectAsState()
    val activeSeason by viewModel.seasonTone.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.statusBarsPadding())
        Spacer(modifier = Modifier.height(20.dp))

        // Screen Header
        Text(
            text = "WARDROBE AI / AGENT",
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = com.example.ui.theme.TextLight
            )
        )
        Text(
            text = "Curator Profile",
            style = MaterialTheme.typography.titleLarge.copy(
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = com.example.ui.theme.TextDark
            )
        )

        Spacer(modifier = Modifier.height(24.dp))

        // User Avatar & Title Card
        FloatingLiquidGlassCard {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shiny custom profile circle
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    com.example.ui.theme.WardrobePrimary,
                                    com.example.ui.theme.WardrobeSecondary,
                                    com.example.ui.theme.WardrobeAccent,
                                    com.example.ui.theme.WardrobePinkAccent,
                                    com.example.ui.theme.WardrobePrimary
                                )
                            )
                        )
                        .border(2.dp, Color.White, CircleShape)
                        .padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = "Avatar icon",
                            tint = com.example.ui.theme.WardrobeSecondary,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = "Alex Curator",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = com.example.ui.theme.TextDark
                    )
                    Text(
                        text = "Level 4 Wardrobe Alchemist",
                        fontSize = 12.sp,
                        color = com.example.ui.theme.TextLight,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x1F7C4DFF))
                            .padding(vertical = 2.dp, horizontal = 8.dp)
                    ) {
                        Text(
                            text = "Aesthetic Score: 98%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.WardrobeSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Styling Profile Stats
        Text(
            text = "Active Ecosystem Preferences",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = com.example.ui.theme.TextDark,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        LiquidGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Style DNA Preference Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Palette,
                            contentDescription = null,
                            tint = com.example.ui.theme.WardrobePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Aesthetic Persona",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = com.example.ui.theme.TextDark
                            )
                            Text(
                                text = activePersona,
                                fontSize = 12.sp,
                                color = com.example.ui.theme.TextLight
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = com.example.ui.theme.DividerColor, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(14.dp))

                // Season tone Preference Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = null,
                            tint = com.example.ui.theme.WardrobeSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Color Harmonization Tone",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = com.example.ui.theme.TextDark
                            )
                            Text(
                                text = activeSeason,
                                fontSize = 12.sp,
                                color = com.example.ui.theme.TextLight
                            )
                        }
                    }
                }
            }
        }

        // Functional Setting Options (Decorative but highly aesthetic)
        Text(
            text = "Ecosystem Integration",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = com.example.ui.theme.TextDark,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        LiquidGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 120.dp) // extra padding to avoid navbar overlapping
        ) {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Option 1
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.CloudSync,
                            contentDescription = "Sync",
                            tint = com.example.ui.theme.WardrobeAccent,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Cloud Capsule Sync",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.TextDark
                        )
                    }
                    Switch(
                        checked = true,
                        onCheckedChange = {},
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = com.example.ui.theme.WardrobePrimary
                        )
                    )
                }

                // Option 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Settings,
                            contentDescription = "Auto",
                            tint = com.example.ui.theme.WardrobeSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Real-time AI Match Scanning",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.TextDark
                        )
                    }
                    Switch(
                        checked = true,
                        onCheckedChange = {},
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = com.example.ui.theme.WardrobeSecondary
                        )
                    )
                }
            }
        }
    }
}
