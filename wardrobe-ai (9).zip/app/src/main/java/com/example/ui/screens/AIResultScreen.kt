package com.example.ui.screens

import android.graphics.Paint
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api.WardrobeAnalysisResult
import com.example.ui.components.FloatingLiquidGlassCard
import com.example.ui.components.LiquidGlassCard
import kotlin.math.cos
import kotlin.math.sin

private val EaseInOutSine = Easing { fraction ->
    -(cos(Math.PI * fraction) - 1f).toFloat() / 2f
}

@Composable
fun AIResultScreen(
    analysis: WardrobeAnalysisResult,
    itemName: String,
    category: String,
    colorName: String,
    colorHex: String,
    description: String,
    onClear: () -> Unit,
    onSaveToWardrobe: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 1. SPRING PHYSICS GAUGE ANIMATION
    var targetScoreProgress by remember { mutableStateOf(0f) }
    LaunchedEffect(analysis.compatibilityScore) {
        animate(
            initialValue = 0f,
            targetValue = analysis.compatibilityScore.toFloat(),
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            )
        ) { value, _ ->
            targetScoreProgress = value
        }
    }

    // 2. TIMERS & PULSES FOR FLOATING PARTICLES & CORE GLOW
    val infiniteTransition = rememberInfiniteTransition(label = "result_screen_core")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_lens"
    )

    val flowProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "atmosphere_flow"
    )

    // Interactive Triage Category selection ("Buy", "Consider", "Skip")
    // By default, match with Gemini Recommendation, with easy tab overrides!
    var activeTriageTab by remember { 
        mutableStateOf(
            if (analysis.recommendation.uppercase() == "BUY") "Buy" else "Consider"
        ) 
    }

    // Dev mode drawer toggle for completely copyable Dart/Flutter script
    var isFlutterDevViewExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF090A0F)) // deep rich premium backplane
    ) {
        // 1. SAPPHIRE/VIOLET ANIMATED MESH BACKPLANE
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Core dark backing tint
            drawRect(color = Color(0xFF07080B))

            val phaseAngle = flowProgress * 2.0 * Math.PI

            // Upper right deep blue glow
            val cx1 = w * 0.75f + cos(phaseAngle).toFloat() * (w * 0.15f)
            val cy1 = h * 0.25f + sin(phaseAngle).toFloat() * (h * 0.1f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF0F3BB0).copy(alpha = 0.45f), Color.Transparent),
                    center = Offset(cx1, cy1),
                    radius = w * 0.85f
                ),
                radius = w * 0.85f
            )

            // Lower left violet aura glow
            val cx2 = w * 0.20f + cos(-phaseAngle).toFloat() * (w * 0.12f)
            val cy2 = h * 0.75f + sin(-phaseAngle).toFloat() * (h * 0.15f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF3B0066).copy(alpha = 0.42f), Color.Transparent),
                    center = Offset(cx2, cy2),
                    radius = w * 0.75f
                ),
                radius = w * 0.75f
            )

            // Center neon cyan mist matching blue gradient request
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF00D4FF).copy(alpha = 0.08f), Color.Transparent),
                    center = Offset(w / 2f, h / 2f),
                    radius = w * 0.65f
                ),
                radius = w * 0.65f
            )
        }

        // 2. MICRO DRIFTING RAINBOW PARTICLES
        Box(modifier = Modifier.fillMaxSize()) {
            val sparkSeeds = remember {
                List(25) { i ->
                    Triple(
                        0.05f + 0.9f * (i * 1.33f % 1f), // base x
                        0.05f + 0.9f * (i * 1.77f % 1f), // base y
                        2f + 4f * (i * 0.75f % 1f)       // size
                    )
                }
            }
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                sparkSeeds.forEach { (bx, by, sizeVal) ->
                    val dy = (by - flowProgress * 0.18f + 1f) % 1f
                    val px = bx * w + sin(flowProgress * 2f * Math.PI.toFloat() * 3f) * 12.dp.toPx()
                    val py = dy * h
                    drawCircle(
                        color = Color(0xFF00D4FF).copy(alpha = 0.18f),
                        radius = sizeVal,
                        center = Offset(px, py)
                    )
                }
            }
        }

        // 3. MAIN SCROLL CONTAINER
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp)
        ) {
            Spacer(modifier = Modifier.statusBarsPadding())
            Spacer(modifier = Modifier.height(16.dp))

            // Premium Screen Navigator Title Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onClear() }
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Stylist Audit Result",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "AI ENGINE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00D4FF),
                        letterSpacing = 1.2.sp
                    )
                }
            }

            // GAUGE DISPLAY CARD (Floating. Glass. Rounded: 32)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        scaleX = pulseScale
                        scaleY = pulseScale
                    }
                    .shadow(16.dp, RoundedCornerShape(32.dp))
                    .clip(RoundedCornerShape(32.dp))
                    .border(1.2.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(32.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.03f))
                        )
                    )
                    .drawBehind {
                        // Light sheen glass swipe
                        val shine = Brush.linearGradient(
                            listOf(Color.White.copy(alpha = 0.1f), Color.Transparent),
                            start = Offset(0f, 0f),
                            end = Offset(size.width * 0.5f, size.height)
                        )
                        drawRect(brush = shine)
                    }
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "CAPSULE HARMONY SCALE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFA0A5C0),
                        letterSpacing = 2.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // LARGE CIRCULAR GAUGE DRAWN IN CANVAS WITH BLUE GRADIENT
                    Box(
                        modifier = Modifier
                            .size(190.dp)
                            .testTag("compatibility_circular_gauge"),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val center = Offset(size.width / 2f, size.height / 2f)
                            val radius = size.width * 0.42f
                            val strokeWidthVal = 14.dp.toPx()

                            // Base Track (Semi-transparent deep indigo trace)
                            drawCircle(
                                color = Color(0xFF1E2845).copy(alpha = 0.45f),
                                radius = radius,
                                center = center,
                                style = Stroke(width = strokeWidthVal, cap = StrokeCap.Round)
                            )

                            // Under-Glow Aura trace (Blurred projection)
                            drawArc(
                                brush = Brush.sweepGradient(
                                    colors = listOf(
                                        Color(0xFF00D4FF).copy(alpha = 0.45f),
                                        Color(0xFF4364F7).copy(alpha = 0.45f),
                                        Color(0xFF0052D4).copy(alpha = 0.15f),
                                        Color(0xFF00D4FF).copy(alpha = 0.45f)
                                    ),
                                    center = center
                                ),
                                startAngle = -90f,
                                sweepAngle = (targetScoreProgress / 100f) * 360f,
                                useCenter = false,
                                style = Stroke(width = strokeWidthVal + 4.dp.toPx(), cap = StrokeCap.Round)
                            )

                            // Main Blue Gradient Active Arc
                            drawArc(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFF00D4FF), // brilliant cyan
                                        Color(0xFF4364F7), // violet power blue
                                        Color(0xFF0052D4)  // master dark blue
                                    ),
                                    start = Offset(0f, 0f),
                                    end = Offset(size.width, size.height)
                                ),
                                startAngle = -90f,
                                sweepAngle = (targetScoreProgress / 100f) * 360f,
                                useCenter = false,
                                style = Stroke(width = strokeWidthVal, cap = StrokeCap.Round)
                            )

                            // Small glossy pointer bulb at the tip
                            val angleRad = Math.toRadians(((-90f + (targetScoreProgress / 100f) * 360f)).toDouble())
                            val tipX = center.x + cos(angleRad).toFloat() * radius
                            val tipY = center.y + sin(angleRad).toFloat() * radius
                            drawCircle(
                                color = Color.White,
                                radius = 6.dp.toPx(),
                                center = Offset(tipX, tipY)
                            )
                        }

                        // Inside Text blocks
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "${analysis.compatibilityScore}%",
                                fontSize = 42.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = (-1).sp
                            )
                            Text(
                                text = if (analysis.compatibilityScore >= 80) "PERFECT FIT" else "DECENT ADAPTER",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF00D4FF),
                                letterSpacing = 1.2.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = itemName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "$category / $colorName",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White.copy(alpha = 0.65f),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            // INTERACTIVE TRIAGE BUTTONS Segment (Buy, Consider, Skip)
            Text(
                text = "INVESTMENT TRIAGE STATS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF90A4AE),
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Glass Segmented Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf("Buy", "Consider", "Skip").forEach { tab ->
                    val isSelected = activeTriageTab == tab
                    val tabColor = when (tab) {
                        "Buy" -> Color(0xFF00FFC4)
                        "Consider" -> Color(0xFF00D4FF)
                        else -> Color(0xFFFF5FA2)
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) Color.White.copy(alpha = 0.12f) else Color.Transparent
                            )
                            .border(
                                1.dp,
                                if (isSelected) tabColor.copy(alpha = 0.5f) else Color.Transparent,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { activeTriageTab = tab }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(tabColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = tab.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.65f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Transitioning Triage content cards based on state with spring anim
            AnimatedVisibility(
                visible = true,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                // Customized detailed content for Buy / Consider / Skip states
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, RoundedCornerShape(24.dp))
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.White.copy(alpha = 0.04f))
                        .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
                        .padding(18.dp)
                ) {
                    when (activeTriageTab) {
                        "Buy" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF00FFC4),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "High Synergy Verification",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 15.sp
                                    )
                                }
                                Text(
                                    text = "This item has been calculated as matching 80% or greater of your standard capsule profile. Recommended to save as a core building block which will amplify outfit count efficiently.",
                                    fontSize = 13.sp,
                                    color = Color.White.copy(alpha = 0.75f),
                                    lineHeight = 18.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Reasoning: ${analysis.reasoning}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF00D4FF)
                                )
                            }
                        }
                        "Consider" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Help,
                                        contentDescription = null,
                                        tint = Color(0xFF00D4FF),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Conditional Styling Adaption",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 15.sp
                                    )
                                }
                                Text(
                                    text = "Consider integrating this spec if you seek to expand seasonal variety. It functions perfectly, but may require specific pairing elements listed below to unlock full visual harmony.",
                                    fontSize = 13.sp,
                                    color = Color.White.copy(alpha = 0.75f),
                                    lineHeight = 18.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AddCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF7C4DFF),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Pairing requirement: ${analysis.keyItemsNeeded.joinToString(", ")}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                }
                            }
                        }
                        "Skip" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Cancel,
                                        contentDescription = null,
                                        tint = Color(0xFFFF5FA2),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Avoid Redundancy Trigger",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 15.sp
                                    )
                                }
                                Text(
                                    text = "Avoid buying if you already own similar indigo/dark specimens, or if the color tone overlaps excessively. Excessive overlaps reduce capsule dynamic performance and cluster wardrobe space unnecessarily.",
                                    fontSize = 13.sp,
                                    color = Color.White.copy(alpha = 0.75f),
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // BEST MATCHES SECTION - Floating. Glass. Rounded: 32
            Text(
                text = "BEST MATCHES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF90A4AE),
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                val demoMatches = listOf(
                    Pair("Relaxed Raw Denim", "Jeans"),
                    Pair("Fine Linen Overpiece", "Shirts"),
                    Pair("Rib Knit Cardigan", "Hoodies"),
                    Pair("Chunky White Trainer", "Shoes")
                )

                demoMatches.forEach { (matchName, matchCat) ->
                    Box(
                        modifier = Modifier
                            .width(160.dp)
                            .shadow(4.dp, RoundedCornerShape(32.dp))
                            .clip(RoundedCornerShape(32.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(32.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .padding(16.dp)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00D4FF).copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Checkroom,
                                    contentDescription = null,
                                    tint = Color(0xFF00D4FF),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = matchName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = matchCat,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF7C4DFF)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // RECOMMENDED OUTFITS SECTION
            Text(
                text = "RECOMMENDED OUTFITS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF90A4AE),
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                analysis.matchingOutfits.forEachIndexed { idx, outfit ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(20.dp))
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(listOf(Color(0xFF0052D4), Color(0xFF4364F7)))
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${idx+1}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = outfit,
                                fontSize = 13.sp,
                                color = Color.White.copy(alpha = 0.85f),
                                lineHeight = 16.sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // COLOR ANALYSIS INTEGRATION
            Text(
                text = "COLOR HARMONY ANALYSIS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF90A4AE),
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White.copy(alpha = 0.04f))
                    .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(
                                        try { Color(android.graphics.Color.parseColor(colorHex)) } 
                                        catch(e: Exception) { Color(0xFF00D4FF) }
                                    )
                                    .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = colorName,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF7C4DFF).copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "ANALOGOUS",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF7C4DFF)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = analysis.colorHarmony,
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.75f),
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Minimal custom-drawn seasonal color spectrum wheel
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black.copy(alpha = 0.2f))
                            .padding(12.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw a visual center chromatic line
                            val spectrumBrush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0xFF4B6F96),
                                    Color(0xFF7F8C6F),
                                    Color(0xFFEADEC9),
                                    Color(0xFF3E2723),
                                    Color(0xFF00D4FF),
                                    Color(0xFF7C4DFF)
                                )
                            )
                            drawRoundRect(
                                brush = spectrumBrush,
                                size = Size(w, 16.dp.toPx()),
                                topLeft = Offset(0f, h / 2f - 8.dp.toPx()),
                                cornerRadius = CornerRadius(8.dp.toPx())
                            )

                            // Pointer on top of detected hue
                            val focusX = w * 0.65f
                            drawCircle(
                                color = Color.White,
                                radius = 7.dp.toPx(),
                                center = Offset(focusX, h / 2f)
                            )
                            drawCircle(
                                color = Color(0xFF00D4FF),
                                radius = 4.dp.toPx(),
                                center = Offset(focusX, h / 2f)
                            )

                            // Text spec indications inside Canvas (or standard Composables)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // FLUTTER DEVELOPER VIEW (ACCORDION)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF13141C))
                    .border(
                        1.dp, 
                        if (isFlutterDevViewExpanded) Color(0xFF4285F4).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.10f), 
                        RoundedCornerShape(24.dp)
                    )
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isFlutterDevViewExpanded = !isFlutterDevViewExpanded }
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = null,
                                tint = Color(0xFF4285F4),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "📋 Flutter Developer View",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                        Icon(
                            imageVector = if (isFlutterDevViewExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.6f)
                        )
                    }

                    if (isFlutterDevViewExpanded) {
                        Divider(color = Color.White.copy(alpha = 0.12f))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Get the completely optimized Flutter equivalent dart class for this exact animated circular score gauge with premium backdrop blurs!",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.5f),
                                modifier = Modifier.padding(bottom = 10.dp)
                            )

                            Text(
                                text = """
import 'dart:math' as math;
import 'package:flutter/material.dart';

class CapsuleScoreGauge extends StatefulWidget {
  final double score; // 0 to 100
  const CapsuleScoreGauge({Key? key, required this.score}) : super(key: key);

  @override
  State<CapsuleScoreGauge> createState() => _CapsuleScoreGaugeState();
}

class _CapsuleScoreGaugeState extends State<CapsuleScoreGauge> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );
    _animation = Tween<double>(begin: 0, end: widget.score).animate(
      CurvedAnimation(parent: _controller, curve: Curves.bounceOut),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return CustomPaint(
          size: const Size(190, 190),
          painter: GaugePainter(_animation.value),
        );
      },
    );
  }
}

class GaugePainter extends CustomPainter {
  final double progress;
  GaugePainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.42;
    final strokeWidth = 14.0;

    // Track Paint
    final trackPaint = Paint()
      ..color = const Color(0xFF1E2845).withOpacity(0.45)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(center, radius, trackPaint);

    // Gradient Arc Paint
    final rect = Rect.fromCircle(center: center, radius: radius);
    final sweepAngle = (progress / 100) * 2 * math.pi;

    final activePaint = Paint()
      ..shader = const SweepGradient(
        colors: [Color(0xFF00D4FF), Color(0xFF4364F7), Color(0xFF0052D4), Color(0xFF00D4FF)],
        stops: [0.0, 0.4, 0.8, 1.0],
      ).createShader(rect)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(rect, -math.pi / 2, sweepAngle, false, activePaint);
  }

  @override
  bool shouldRepaint(covariant GaugePainter oldDelegate) => oldDelegate.progress != progress;
}
                                """.trimIndent(),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF00FFC4),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                                    .horizontalScroll(rememberScrollState())
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // SAVE & RESET ACTIONS
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(24.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text(
                            text = "LENS CONFIRMATION",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.5f),
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = if (analysis.recommendation.uppercase() == "BUY") "Highly Recommended" else "Add conditionally",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = if (analysis.recommendation.uppercase() == "BUY") Color(0xFF00FFC4) else Color(0xFF00D4FF),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onClear,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color.White
                            ),
                            border = BorderStroke(1.2.dp, Color.White.copy(alpha = 0.25f))
                        ) {
                            Text("Reset", fontSize = 12.sp)
                        }

                        Button(
                            onClick = onSaveToWardrobe,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (analysis.recommendation.uppercase() == "BUY") Color(0xFF00D4FF) else Color(0xFF4285F4)
                            ),
                            modifier = Modifier.testTag("save_and_integrate_button")
                        ) {
                            Text(
                                text = "ADD TO PIECES",
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(120.dp))
        }
    }
}
