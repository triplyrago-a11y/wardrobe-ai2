package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiApiClient
import com.example.api.WardrobeAnalysisResult
import com.example.data.AppDatabase
import com.example.data.WardrobeItem
import com.example.data.WardrobeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ScanStatus {
    object Idle : ScanStatus
    object Scanning : ScanStatus
    data class Success(
        val result: WardrobeAnalysisResult,
        val itemName: String,
        val category: String,
        val colorName: String,
        val colorHex: String,
        val itemDescription: String
    ) : ScanStatus
    data class Error(val message: String) : ScanStatus
}

class WardrobeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = WardrobeRepository(db.wardrobeDao())

    val allWardrobeItems: StateFlow<List<WardrobeItem>> = repository.allItems
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _scanStatus = MutableStateFlow<ScanStatus>(ScanStatus.Idle)
    val scanStatus: StateFlow<ScanStatus> = _scanStatus.asStateFlow()

    // Interactive custom user styling persona
    private val _stylePersona = MutableStateFlow("Quiet Luxury")
    val stylePersona: StateFlow<String> = _stylePersona.asStateFlow()

    private val _seasonTone = MutableStateFlow("Cool Winter (High Contrast)")
    val seasonTone: StateFlow<String> = _seasonTone.asStateFlow()

    init {
        // Automatically seed beautifully styled capsule wardrobe garments on launch if database is empty
        viewModelScope.launch {
            repository.seedInitialDataIfNecessary()
        }
    }

    fun setStylePersona(persona: String) {
        _stylePersona.value = persona
    }

    fun setSeasonTone(tone: String) {
        _seasonTone.value = tone
    }

    fun addWardrobeItem(name: String, category: String, colorName: String, colorHex: String, description: String) {
        viewModelScope.launch {
            val newItem = WardrobeItem(
                name = name,
                category = category,
                colorName = colorName,
                colorHex = colorHex,
                description = description.ifEmpty { "Elegant $category base item." }
            )
            repository.insert(newItem)
        }
    }

    fun removeWardrobeItem(item: WardrobeItem) {
        viewModelScope.launch {
            repository.delete(item)
        }
    }

    fun removeWardrobeItemById(id: Int) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    /**
     * Triggers active scanning and compatibility computation of a new apparel garment using Gemini AI.
     */
    fun scanShoppingItem(
        name: String,
        category: String,
        colorName: String,
        colorHex: String,
        description: String
    ) {
        _scanStatus.value = ScanStatus.Scanning
        viewModelScope.launch {
            try {
                // Collect a list of current items to pass as stylist context
                val currentWardrobe = allWardrobeItems.value
                val analysis = GeminiApiClient.analyzeItemCompatibility(
                    newItemName = name,
                    newItemCategory = category,
                    newItemColorName = colorName,
                    newItemColorHex = colorHex,
                    newItemDescription = description,
                    existingWardrobe = currentWardrobe
                )
                _scanStatus.value = ScanStatus.Success(
                    result = analysis,
                    itemName = name,
                    category = category,
                    colorName = colorName,
                    colorHex = colorHex,
                    itemDescription = description
                )
            } catch (e: Exception) {
                _scanStatus.value = ScanStatus.Error(e.localizedMessage ?: "Stylist API connection failed.")
            }
        }
    }

    fun clearScan() {
        _scanStatus.value = ScanStatus.Idle
    }

    fun addScannedItemToWardrobe(name: String, category: String, colorName: String, colorHex: String, description: String) {
        viewModelScope.launch {
            val item = WardrobeItem(
                name = name,
                category = category,
                colorName = colorName,
                colorHex = colorHex,
                description = description
            )
            repository.insert(item)
        }
    }

    // Factory pattern to instantiate AndroidViewModel safely from Composable views
    class Factory(private val application: Application) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(WardrobeViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return WardrobeViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
