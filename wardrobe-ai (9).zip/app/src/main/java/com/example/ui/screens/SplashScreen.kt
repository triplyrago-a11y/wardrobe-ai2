package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

// High quality linear color interpolator
private fun lerpColor(start: Color, stop: Color, fraction: Float): Color {
    return Color(
        red = start.red + (stop.red - start.red) * fraction,
        green = start.green + (stop.green - start.green) * fraction,
        blue = start.blue + (stop.blue - start.blue) * fraction,
        alpha = start.alpha + (stop.alpha - start.alpha) * fraction,
        colorSpace = start.colorSpace
    )
}

// Ease curves for luxurious motion dynamics
private fun easeInOutSine(t: Float): Float {
    return (-(cos(PI * t) - 1f) / 2f).toFloat()
}

private fun easeOutQuad(t: Float): Float {
    return t * (2f - t)
}

private fun cubicBezier(t: Float): Float {
    return t * t * (3f - 2f * t)
}

@Composable
fun SplashScreen(
    modifier: Modifier = Modifier,
    onFinished: () -> Unit
) {
    // 7000ms narrative timeline animation progress (0f to 1f)
    val progressAnim = remember { Animatable(0f) }

    // Floating loop timer for continuous fluid elements
    val infiniteTransition = rememberInfiniteTransition(label = "perpetual_splash_movement")
    val liquidTime by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = PI.toFloat() * 2f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "liquid_time"
    )

    LaunchedEffect(Unit) {
        // Animate progress smoothly over exactly 7 seconds (7000ms)
        progressAnim.animateTo(
            targetValue = 1f,
            animationSpec = tween(7000, easing = LinearEasing)
        )
        onFinished()
    }

    val progress = progressAnim.value
    val density = LocalDensity.current
    val config = LocalConfiguration.current

    val screenWidthPx = with(density) { config.screenWidthDp.dp.toPx() }
    val screenHeightPx = with(density) { config.screenHeightDp.dp.toPx() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("app_splash_root")
            .drawBehind {
                // Background is ALWAYS pure white as per theme rules
                drawRect(color = Color.White)

                // Very soft animated mesh gradient with Opacity 5% (0.05)
                val meshAlpha = 0.05f
                val cx1 = size.width * (0.35f + 0.15f * sin(liquidTime))
                val cy1 = size.height * (0.45f + 0.12f * cos(liquidTime * 0.8f))
                val cx2 = size.width * (0.65f + 0.18f * cos(liquidTime * 0.7f))
                val cy2 = size.height * (0.55f + 0.15f * sin(liquidTime * 0.9f))
                val cx3 = size.width * (0.50f + 0.10f * sin(liquidTime * 1.2f))
                val cy3 = size.height * (0.25f + 0.10f * cos(liquidTime * 0.6f))

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF4285F4).copy(alpha = meshAlpha), Color.Transparent),
                        center = Offset(cx1, cy1),
                        radius = size.width * 0.85f
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF7C4DFF).copy(alpha = meshAlpha), Color.Transparent),
                        center = Offset(cx2, cy2),
                        radius = size.width * 0.90f
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF00D4FF).copy(alpha = meshAlpha * 0.8f), Color.Transparent),
                        center = Offset(cx3, cy3),
                        radius = size.width * 0.75f
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFFFF5FA2).copy(alpha = meshAlpha * 0.6f), Color.Transparent),
                        center = Offset(size.width * 0.2f, size.height * 0.8f),
                        radius = size.width * 0.65f
                    )
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val centerX = width / 2f
            val centerY = height / 2f

            // Target Top Right placement for the shared element final state
            val targetRightCornerX = width - 34.dp.toPx()
            val targetRightCornerY = 44.dp.toPx()

            // SCENE 1 (Background Calmness): 0.0s to 1.0s (progress 0.0 to 0.143)
            // Just the mesh gradient background is shown.

            // SCENE 2 (Tiny Glowing Center Dot & Ripple): 1.0s to 2.0s (progress 0.143 to 0.286)
            if (progress in 0.143f..0.286f) {
                val t2 = ((progress - 0.143f) / 0.143f).coerceIn(0f, 1f)
                drawCircularDotAndRipple(centerX, centerY, t2)
            }

            // SCENE 3 (Glowing Thread Weaving Outline): 2.0s to 4.5s (progress 0.286 to 0.643)
            if (progress in 0.286f..0.643f) {
                val t3 = ((progress - 0.286f) / 0.357f).coerceIn(0f, 1f)
                drawWeavingJacketOutline(centerX, centerY, t3, liquidTime)
            }

            // SCENE 4 (Liquid Glass Jacket Filling & Breathing): 4.5s to 5.4s (progress 0.643 to 0.771)
            if (progress in 0.643f..0.771f) {
                val t4 = ((progress - 0.643f) / 0.128f).coerceIn(0f, 1f)
                drawBreathingLiquidGlassJacket(centerX, centerY, t4, liquidTime)
            }

            // SCENE 5 (Melting & Morphing to central orb): 5.4s to 6.1s (progress 0.771 to 0.871)
            if (progress in 0.771f..0.871f) {
                val t5 = ((progress - 0.771f) / 0.100f).coerceIn(0f, 1f)
                drawMeltingMorphJacketToOrb(centerX, centerY, t5, liquidTime)
            }

            // SCENE 6 (Orb Gentlest Holding Centered & floating): 6.1s to 6.7s (progress 0.871 to 0.957)
            if (progress in 0.871f..0.957f) {
                drawFloatingLiquidGlassOrb(centerX, centerY + sin(liquidTime) * 6f, 64.dp.toPx(), 1f, liquidTime)
            }

            // SCENE 7 & 8 (Orb shrinks and flies to Top-Right context corner): 6.7s to 7.0s (progress 0.957 to 1.0)
            if (progress >= 0.957f) {
                val t7 = ((progress - 0.957f) / 0.043f).coerceIn(0f, 1f)
                val smoothFly = easeInOutSine(t7)
                
                val currentOrbX = centerX + (targetRightCornerX - centerX) * smoothFly
                val currentOrbY = centerY + (targetRightCornerY - centerY) * smoothFly
                val currentOrbRadius = 64.dp.toPx() + (14.dp.toPx() - 64.dp.toPx()) * smoothFly

                drawFloatingLiquidGlassOrb(
                    currentOrbX,
                    currentOrbY,
                    currentOrbRadius,
                    (1f - t7).coerceIn(0f, 1f), // fade internal details nicely
                    liquidTime
                )
            }
        }

        // SCENE 6 (Large text below the centered orb): 6.1s to 6.7s (progress 0.871 to 0.957)
        // With fade-out during Scene 7 (from 6.7s to 7.0s)
        if (progress >= 0.857f) {
            val textShowProg = ((progress - 0.857f) / 0.05f).coerceIn(0f, 1f)
            val textHideProg = if (progress >= 0.957f) {
                ((progress - 0.957f) / 0.033f).coerceIn(0f, 1f)
            } else {
                0f
            }

            val finalAlpha = (easeInOutSine(textShowProg) * (1f - textHideProg)).coerceIn(0f, 1f)
            val textYOffset = (16f * (1f - easeInOutSine(textShowProg))).dp

            Column(
                modifier = Modifier
                    .offset(y = 120.dp + textYOffset)
                    .alpha(finalAlpha)
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "WARDROBE AI",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 32.sp,
                    letterSpacing = 6.sp,
                    color = Color(0xFF13141C),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.drawBehind {
                        // Gloss shine shine sweep across text
                        val sweepProg = ((progress - 0.857f) / 0.100f).coerceIn(0f, 1f)
                        val sweepX = size.width * 2f * sweepProg - size.width
                        val glossSweep = Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.65f),
                                Color.Transparent
                            ),
                            start = Offset(sweepX, 0f),
                            end = Offset(sweepX + 45.dp.toPx(), size.height)
                        )
                        drawRect(brush = glossSweep, blendMode = BlendMode.SrcAtop)
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "AESTHETIC INTELLIGENCE",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    letterSpacing = 4.sp,
                    color = Color(0xFF7C4DFF).copy(alpha = 0.85f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// SCENE 2 Helper: Dot grows and gives circle water ripple effect
private fun DrawScope.drawCircularDotAndRipple(
    centerX: Float,
    centerY: Float,
    t: Float
) {
    val dotRadius = 3.dp.toPx() + 9.dp.toPx() * easeOutQuad(t)
    val dotAlpha = (1f - t).coerceIn(0f, 1f)

    // Center Core dot
    if (dotAlpha > 0f) {
        drawCircle(
            color = Color(0xFF4285F4).copy(alpha = dotAlpha),
            radius = dotRadius,
            center = Offset(centerX, centerY)
        )
    }

    // Secondary expansion expanding water touch ripple
    val rippleRadius = 140.dp.toPx() * easeOutQuad(t)
    val rippleAlpha = (1f - t).coerceIn(0f, 1f) * 0.45f

    if (rippleAlpha > 0f) {
        // Outer Glass Rim
        drawCircle(
            color = Color(0xFF4285F4).copy(alpha = rippleAlpha),
            radius = rippleRadius,
            center = Offset(centerX, centerY),
            style = Stroke(width = 1.5.dp.toPx())
        )

        // Soft Radial Glass Glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF4285F4).copy(alpha = rippleAlpha * 0.2f), Color.Transparent),
                center = Offset(centerX, centerY),
                radius = rippleRadius * 1.1f
            ),
            radius = rippleRadius,
            center = Offset(centerX, centerY)
        )

        // Light specular shine inside water ripple ring
        drawArc(
            brush = Brush.linearGradient(
                colors = listOf(Color.White.copy(alpha = rippleAlpha * 0.8f), Color.Transparent),
                start = Offset(centerX - rippleRadius, centerY - rippleRadius),
                end = Offset(centerX + rippleRadius, centerY + rippleRadius)
            ),
            startAngle = 180f,
            sweepAngle = 90f,
            useCenter = false,
            style = Stroke(width = 1.dp.toPx())
        )
    }
}

// SCENE 3 Helper: Thread drawing outline
private fun DrawScope.drawWeavingJacketOutline(
    centerX: Float,
    centerY: Float,
    t: Float,
    liquidTime: Float
) {
    val scale = 1.8f
    val visualYTranslate = 5f.dp.toPx()

    // Map global Scene 3 timeline over individual segments
    // Collar: 0f to 0.2f, Left Sleeve: 0.2f to 0.4f, Right Sleeve: 0.4f to 0.6f, Body: 0.6f to 0.8f, Buttons: 0.8f to 1.0f
    val fCollar = (t / 0.2f).coerceIn(0f, 1f)
    val fLeftSleeve = ((t - 0.2f) / 0.2f).coerceIn(0f, 1f)
    val fRightSleeve = ((t - 0.4f) / 0.2f).coerceIn(0f, 1f)
    val fBody = ((t - 0.6f) / 0.2f).coerceIn(0f, 1f)
    val fButtons = ((t - 0.8f) / 0.2f).coerceIn(0f, 1f)

    val collarPath = Path().apply {
        moveTo(centerX + 0f, centerY - 56f * scale + visualYTranslate)
        lineTo(centerX - 18f * scale, centerY - 42f * scale + visualYTranslate)
        lineTo(centerX + 0f, centerY - 12f * scale + visualYTranslate)
        lineTo(centerX + 18f * scale, centerY - 42f * scale + visualYTranslate)
        close()
    }

    val leftSleevePath = Path().apply {
        moveTo(centerX - 18f * scale, centerY - 42f * scale + visualYTranslate)
        quadraticTo(
            centerX - 50f * scale, centerY - 35f * scale + visualYTranslate,
            centerX - 62f * scale, centerY - 8f * scale + visualYTranslate
        )
        lineTo(centerX - 72f * scale, centerY + 45f * scale + visualYTranslate)
        lineTo(centerX - 58f * scale, centerY + 48f * scale + visualYTranslate)
        lineTo(centerX - 50f * scale, centerY + 10f * scale + visualYTranslate)
    }

    val rightSleevePath = Path().apply {
        moveTo(centerX + 18f * scale, centerY - 42f * scale + visualYTranslate)
        quadraticTo(
            centerX + 50f * scale, centerY - 35f * scale + visualYTranslate,
            centerX + 62f * scale, centerY - 8f * scale + visualYTranslate
        )
        lineTo(centerX + 72f * scale, centerY + 45f * scale + visualYTranslate)
        lineTo(centerX + 58f * scale, centerY + 48f * scale + visualYTranslate)
        lineTo(centerX + 50f * scale, centerY + 10f * scale + visualYTranslate)
    }

    val bodyPath = Path().apply {
        moveTo(centerX - 50f * scale, centerY + 10f * scale + visualYTranslate)
        lineTo(centerX - 46f * scale, centerY + 70f * scale + visualYTranslate)
        quadraticTo(
            centerX - 22f * scale, centerY + 80f * scale + visualYTranslate,
            centerX + 0f, centerY + 76f * scale + visualYTranslate
        )
        quadraticTo(
            centerX + 22f * scale, centerY + 80f * scale + visualYTranslate,
            centerX + 46f * scale, centerY + 70f * scale + visualYTranslate
        )
        lineTo(centerX + 50f * scale, centerY + 10f * scale + visualYTranslate)

        moveTo(centerX + 0f, centerY - 12f * scale + visualYTranslate)
        lineTo(centerX + 0f, centerY + 76f * scale + visualYTranslate)
    }

    val buttonsPath = Path().apply {
        moveTo(centerX - 24f * scale, centerY + 12f * scale + visualYTranslate)
        lineTo(centerX - 10f * scale, centerY + 12f * scale + visualYTranslate)
        moveTo(centerX + 24f * scale, centerY + 12f * scale + visualYTranslate)
        lineTo(centerX + 10f * scale, centerY + 12f * scale + visualYTranslate)
    }

    // Render the active progress traces
    if (fCollar > 0f) {
        drawPartialPathWithGlow(collarPath, fCollar, Color(0xFF4285F4))
    }
    if (fLeftSleeve > 0f) {
        drawPartialPathWithGlow(leftSleevePath, fLeftSleeve, Color(0xFF4285F4))
    }
    if (fRightSleeve > 0f) {
        drawPartialPathWithGlow(rightSleevePath, fRightSleeve, Color(0xFF7C4DFF))
    }
    if (fBody > 0f) {
        drawPartialPathWithGlow(bodyPath, fBody, Color(0xFF7C4DFF))
    }
    if (fButtons > 0f) {
        drawPartialPathWithGlow(buttonsPath, fButtons, Color(0xFF00D4FF))
        
        // Soft button dots drawn live
        drawCircle(
            color = Color(0xFF00D4FF).copy(alpha = fButtons * 0.9f),
            radius = 3f,
            center = Offset(centerX, centerY + 15f * scale + visualYTranslate)
        )
        drawCircle(
            color = Color(0xFF7C4DFF).copy(alpha = fButtons * 0.9f),
            radius = 3f,
            center = Offset(centerX, centerY + 45f * scale + visualYTranslate)
        )
    }

    // Sparkles dancing on the thread
    val sparkCount = 6
    for (i in 0 until sparkCount) {
        val sparkAng = liquidTime + i * (PI.toFloat() * 2f / sparkCount)
        val rS = (72f + 14f * sin(liquidTime * 1.4f + i)) * scale
        val spX = centerX + rS * cos(sparkAng)
        val spY = centerY + rS * sin(sparkAng) + visualYTranslate
        drawCircle(
            color = Color(0xFF7C4DFF).copy(alpha = 0.45f),
            radius = 2.dp.toPx(),
            center = Offset(spX, spY)
        )
    }
}

// Draw a piece of the path with elegant lighting and glow tips
private fun DrawScope.drawPartialPathWithGlow(
    originalPath: Path,
    fraction: Float,
    baseColor: Color
) {
    val pathMeasure = android.graphics.PathMeasure()
    val rawPath = originalPath.asAndroidPath()
    pathMeasure.setPath(rawPath, false)

    val endDistance = pathMeasure.length * fraction

    val segmentPath = Path()
    val dstAndroid = segmentPath.asAndroidPath()
    pathMeasure.getSegment(0f, endDistance, dstAndroid, true)

    // Outer underlying glow line
    drawPath(
        path = segmentPath,
        color = baseColor.copy(alpha = 0.35f),
        style = Stroke(width = 4.5.dp.toPx(), cap = StrokeCap.Round)
    )

    // Ultra-crisp luxury center wire profile
    drawPath(
        path = segmentPath,
        color = Color.White,
        style = Stroke(width = 1.2.dp.toPx(), cap = StrokeCap.Round)
    )

    // Endpoint fiber spark
    val pos = FloatArray(2)
    val tan = FloatArray(2)
    if (pathMeasure.getPosTan(endDistance, pos, tan)) {
        drawCircle(
            color = baseColor,
            radius = 4.dp.toPx(),
            center = Offset(pos[0], pos[1])
        )
        drawCircle(
            color = Color.White,
            radius = 1.5.dp.toPx(),
            center = Offset(pos[0], pos[1])
        )
    }
}

// SCENE 4 Helper: Fill outline with gorgeous refracted Liquid Glass
private fun DrawScope.drawBreathingLiquidGlassJacket(
    centerX: Float,
    centerY: Float,
    t: Float,
    liquidTime: Float
) {
    val scale = 1.8f
    val visualYTranslate = 5f.dp.toPx()

    // Smooth breathing scaling 1.0 -> 1.03 -> 1.0
    val breathFactor = 1f + 0.03f * sin(liquidTime)

    val jacketShape = Path().apply {
        moveTo(centerX + 0f, centerY - 56f * scale + visualYTranslate)
        lineTo(centerX - 18f * scale, centerY - 42f * scale + visualYTranslate)
        quadraticTo(
            centerX - 50f * scale, centerY - 35f * scale + visualYTranslate,
            centerX - 62f * scale, centerY - 8f * scale + visualYTranslate
        )
        lineTo(centerX - 72f * scale, centerY + 45f * scale + visualYTranslate)
        lineTo(centerX - 58f * scale, centerY + 48f * scale + visualYTranslate)
        lineTo(centerX - 50f * scale, centerY + 10f * scale + visualYTranslate)
        lineTo(centerX - 46f * scale, centerY + 70f * scale + visualYTranslate)
        quadraticTo(
            centerX - 22f * scale, centerY + 80f * scale + visualYTranslate,
            centerX + 0f, centerY + 76f * scale + visualYTranslate
        )
        quadraticTo(
            centerX + 22f * scale, centerY + 80f * scale + visualYTranslate,
            centerX + 46f * scale, centerY + 70f * scale + visualYTranslate
        )
        lineTo(centerX + 50f * scale, centerY + 10f * scale + visualYTranslate)
        lineTo(centerX + 58f * scale, centerY + 48f * scale + visualYTranslate)
        lineTo(centerX + 72f * scale, centerY + 45f * scale + visualYTranslate)
        quadraticTo(
            centerX + 50f * scale, centerY - 35f * scale + visualYTranslate,
            centerX + 18f * scale, centerY - 42f * scale + visualYTranslate
        )
        close()
    }

    withTransform({
        scale(breathFactor, breathFactor, Offset(centerX, centerY))
    }) {
        // 1. Draw Liquid colors inside the jacket using clipping
        clipPath(jacketShape) {
            val fluidCenter = Offset(
                centerX + sin(liquidTime * 0.8f) * 20f,
                centerY + cos(liquidTime) * 30f
            )
            val glassBodyGradient = Brush.radialGradient(
                colors = listOf(
                    Color(0xFF7C4DFF).copy(alpha = 0.35f * t),
                    Color(0xFF4285F4).copy(alpha = 0.25f * t),
                    Color(0xFF00D4FF).copy(alpha = 0.15f * t),
                    Color.Transparent
                ),
                center = fluidCenter,
                radius = 110.dp.toPx()
            )
            drawRect(brush = glassBodyGradient)

            // Semi-transparent glazed glass surface wash
            drawRect(color = Color.White.copy(alpha = 0.13f * t))

            // Subtle internal glass particles
            for (p in 1..8) {
                val seed = p * 60f
                val fx = centerX + sin(liquidTime + seed) * 35f * scale
                val fy = centerY + cos(liquidTime * 0.9f + seed) * 50f * scale
                drawCircle(
                    color = Color.White.copy(alpha = 0.38f * t),
                    radius = (1.5f + (p % 3) * 1.2f).dp.toPx(),
                    center = Offset(fx, fy)
                )
            }
        }

        // 2. Draw Jacket Outermost Outline
        drawPath(
            path = jacketShape,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.85f * t),
                    Color.White.copy(alpha = 0.20f),
                    Color(0xFF4285F4).copy(alpha = 0.60f * t)
                ),
                start = Offset(centerX - 60f * scale, centerY - 60f * scale),
                end = Offset(centerX + 60f * scale, centerY + 80f * scale)
            ),
            style = Stroke(width = 1.8.dp.toPx())
        )

        // 3. Dynamic glass specular shine sweep across the glass surface
        val shineProg = (liquidTime % PI.toFloat()) / PI.toFloat()
        val shineX = (centerX - 120f * scale) + (240f * scale * shineProg)
        drawLine(
            color = Color.White.copy(alpha = 0.28f * t),
            start = Offset(shineX, centerY - 90f * scale),
            end = Offset(shineX + 35f, centerY + 90f * scale),
            strokeWidth = 2.dp.toPx()
        )
    }
}

// SCENE 5 Helper: Compress the jacket and blend into a condensed sphere
private fun DrawScope.drawMeltingMorphJacketToOrb(
    centerX: Float,
    centerY: Float,
    t: Float,
    liquidTime: Float
) {
    val scale = 1.8f
    val compressionFactor = 1f - t

    val maxJacketRadius = 72f * scale
    val sphereRadius = 64.dp.toPx() * easeOutQuad(t)

    // Blend back and forth colors
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFF4285F4).copy(alpha = 0.65f * t),
                Color(0xFF7C4DFF).copy(alpha = 0.50f * t),
                Color(0xFF00D4FF).copy(alpha = 0.25f * t),
                Color.Transparent
            ),
            center = Offset(centerX, centerY),
            radius = sphereRadius * 1.5f
        ),
        radius = sphereRadius,
        center = Offset(centerX, centerY)
    )

    if (t < 0.95f) {
        val jacketFade = (1f - t).coerceIn(0f, 1f)
        withTransform({
            scale(compressionFactor, compressionFactor, Offset(centerX, centerY))
        }) {
            drawBreathingLiquidGlassJacket(centerX, centerY, jacketFade, liquidTime)
        }
    }
}

// Draws the floating glowing orb in real-time
private fun DrawScope.drawFloatingLiquidGlassOrb(
    orbX: Float,
    orbY: Float,
    orbRadius: Float,
    renderDetailsAlpha: Float,
    liquidTime: Float
) {
    // Soft animated light breathing
    val breath = 1f + 0.035f * sin(liquidTime * 1.2f)
    val activeRadius = orbRadius * breath

    // 1. Aura glow background (Google AI theme)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFF7C4DFF).copy(alpha = 0.35f * renderDetailsAlpha),
                Color(0xFF4285F4).copy(alpha = 0.20f * renderDetailsAlpha),
                Color(0xFF00D4FF).copy(alpha = 0.10f * renderDetailsAlpha),
                Color.Transparent
            ),
            center = Offset(orbX, orbY),
            radius = activeRadius * 2.2f
        ),
        radius = activeRadius * 2.2f,
        center = Offset(orbX, orbY)
    )

    // 2. Liquid Glass outer perimeter highlight
    drawCircle(
        brush = Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.88f),
                Color(0xFFE2E9FF).copy(alpha = 0.35f),
                Color(0xFF7C4DFF).copy(alpha = 0.50f)
            ),
            start = Offset(orbX - activeRadius, orbY - activeRadius),
            end = Offset(orbX + activeRadius, orbY + activeRadius)
        ),
        radius = activeRadius,
        center = Offset(orbX, orbY)
    )

    // 3. Inner colorful glass core wash
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFF00D4FF).copy(alpha = 0.50f * renderDetailsAlpha),
                Color(0xFF7C4DFF).copy(alpha = 0.40f * renderDetailsAlpha),
                Color(0xFF4285F4).copy(alpha = 0.25f * renderDetailsAlpha),
                Color.Transparent
            ),
            center = Offset(orbX + activeRadius * 0.15f, orbY - activeRadius * 0.15f),
            radius = activeRadius * 1.2f
        ),
        radius = activeRadius * 0.95f,
        center = Offset(orbX, orbY)
    )

    // 4. White accent rim outline
    drawCircle(
        color = Color.White.copy(alpha = 0.65f),
        radius = activeRadius,
        center = Offset(orbX, orbY),
        style = Stroke(width = 1.5.dp.toPx())
    )

    // 5. Tiny stars and micro-particles moving inside sphere
    if (renderDetailsAlpha > 0.1f) {
        for (i in 1..5) {
            val seed = i * 45f
            val px = orbX + sin(liquidTime * 0.6f + seed) * activeRadius * 0.5f
            val py = orbY + cos(liquidTime * 0.5f + seed) * activeRadius * 0.5f
            drawCircle(
                color = Color.White.copy(alpha = 0.45f * renderDetailsAlpha),
                radius = 1.5.dp.toPx(),
                center = Offset(px, py)
            )
        }
    }
}
