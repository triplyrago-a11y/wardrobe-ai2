package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FloatingLiquidGlassCard
import com.example.ui.components.LiquidGlassCard
import com.example.ui.viewmodel.WardrobeViewModel

@Composable
fun HomeScreen(
    viewModel: WardrobeViewModel,
    onNavigateToTab: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val items by viewModel.allWardrobeItems.collectAsState()
    val activePersona by viewModel.stylePersona.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    // Filtered items based on search query
    val filteredItems = remember(items, searchQuery) {
        if (searchQuery.isBlank()) {
            items
        } else {
            items.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.category.contains(searchQuery, ignoreCase = true) ||
                        it.colorName.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.statusBarsPadding())
        Spacer(modifier = Modifier.height(20.dp))

        // Screen Header Section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Hey Dhruv 👋",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.SansSerif,
                        color = com.example.ui.theme.TextDark
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your AI Fashion Companion",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = com.example.ui.theme.TextLight
                    )
                )
            }

            // Tiny floating Gemini Orb: Liquid Glass, Blue Glow, Slow Floating Animation
            val infiniteGlow = rememberInfiniteTransition(label = "gemini_orb_inf")
            val floatAnim by infiniteGlow.animateFloat(
                initialValue = -5f,
                targetValue = 5f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2800, easing = LinearOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "orb_float"
            )
            val glowAnim by infiniteGlow.animateFloat(
                initialValue = 0.4f,
                targetValue = 0.8f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2000, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "orb_glow"
            )

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .offset(y = floatAnim.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.25f))
                    .border(
                        width = 1.2.dp,
                        color = Color.White.copy(alpha = 0.65f),
                        shape = CircleShape
                    )
                    .drawBehind {
                        // Soft elegant blue glow as requested
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF4285F4).copy(alpha = glowAnim * 0.4f),
                                    Color.Transparent
                                ),
                                center = Offset(size.width / 2f, size.height / 2f),
                                radius = size.width * 1.5f
                            ),
                            radius = size.width * 1.5f
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                // Liquid glass core containing a sweep gradient of Gemini signature color bands
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    Color(0xFF4285F4), // Blue
                                    Color(0xFF00D4FF), // Cyan
                                    Color(0xFFFF5FA2), // Pink
                                    Color(0xFF7C4DFF), // Purple
                                    Color(0xFF4285F4)
                                )
                            )
                        )
                )
                // Reflective droplets specular shine
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .drawBehind {
                            drawCircle(
                                color = Color.White.copy(alpha = 0.65f),
                                radius = size.width * 0.15f,
                                center = Offset(size.width * 0.35f, size.height * 0.35f)
                            )
                        }
                )
            }
        }

        // Search Bar Section: Large Glass Search Bar, corners 40, Blur 30 visual styling
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(40.dp))
                .background(Color.White.copy(alpha = 0.4f)) // adjusted to slightly more rich to enhance search legibility
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(40.dp)
                )
                .drawBehind {
                    val w = size.width
                    val h = size.height
                    // Dynamic glass reflection gloss
                    val glossBrush = Brush.linearGradient(
                        colors = listOf(Color.White.copy(alpha = 0.15f), Color.Transparent),
                        start = Offset(0f, 0f),
                        end = Offset(w * 0.35f, h)
                    )
                    drawRect(brush = glossBrush)
                }
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = com.example.ui.theme.TextLight,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))

                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    textStyle = TextStyle(
                        color = com.example.ui.theme.TextDark,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.SansSerif
                    ),
                    cursorBrush = SolidColor(com.example.ui.theme.WardrobePrimary),
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    decorationBox = { innerTextField ->
                        if (searchQuery.isEmpty()) {
                            Text(
                                text = "Search your wardrobe...",
                                color = com.example.ui.theme.TextLight.copy(alpha = 0.8f),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                fontFamily = FontFamily.SansSerif
                            )
                        }
                        innerTextField()
                    }
                )

                if (searchQuery.isNotEmpty()) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear",
                        tint = com.example.ui.theme.TextLight,
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { searchQuery = "" }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Main Card: Floating Liquid Glass Card representing Wardrobe Health
        FloatingLiquidGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Wardrobe Health",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = com.example.ui.theme.TextLight
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "85%",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.SansSerif,
                            color = com.example.ui.theme.TextDark
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Your wardrobe is versatile and balanced.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = com.example.ui.theme.TextLight,
                            lineHeight = 20.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Animated Circular Progress Ring
                val animatedProgress = remember { Animatable(0f) }
                LaunchedEffect(Unit) {
                    animatedProgress.animateTo(
                        targetValue = 0.85f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessVeryLow
                        )
                    )
                }

                Box(
                    modifier = Modifier.size(88.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 9.dp.toPx()
                        val ringRadius = (size.width - strokeWidth) / 2f

                        // Under-track
                        drawCircle(
                            color = Color.White.copy(alpha = 0.35f),
                            radius = ringRadius,
                            style = Stroke(width = strokeWidth)
                        )

                        // Progress dynamic arc
                        drawArc(
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    com.example.ui.theme.WardrobePrimary,
                                    com.example.ui.theme.WardrobeSecondary,
                                    com.example.ui.theme.WardrobeAccent,
                                    com.example.ui.theme.WardrobePrimary
                                ),
                                center = Offset(size.width / 2f, size.height / 2f)
                            ),
                            startAngle = -90f,
                            sweepAngle = 360f * animatedProgress.value,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${(animatedProgress.value * 100).toInt()}%",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = com.example.ui.theme.TextDark
                        )
                        Text(
                            text = "INDEX",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.TextLight,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // Section: Outfit Recommendations Header
        Text(
            text = "AI Stylist Recommendations",
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.SansSerif,
            color = com.example.ui.theme.TextDark,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Horizontal Outfit Recommendation Cards (Glass override, round 28, minimal text)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            val recommendationsList = listOf(
                RecommendationItem(
                    title = "Quiet Luxury Capsule",
                    desc = "Cashmere + Linen",
                    primaryColor = Color(0xFFF5F5DC),
                    secColor = Color(0xFF64748B),
                    icon = Icons.Outlined.Checkroom
                ),
                RecommendationItem(
                    title = "Monochrome Street",
                    desc = "Oversized + Denim",
                    primaryColor = Color(0xFF1E293B),
                    secColor = Color(0xFF00D4FF),
                    icon = Icons.Outlined.Style
                ),
                RecommendationItem(
                    title = "Warm Sunset Blend",
                    desc = "Knitwear + Amber",
                    primaryColor = Color(0xFFFF5FA2),
                    secColor = Color(0xFF7C4DFF),
                    icon = Icons.Outlined.WbSunny
                )
            )

            recommendationsList.forEach { rec ->
                LiquidGlassCard(
                    cornerRadius = 28.dp, // Rounded 28
                    modifier = Modifier.width(220.dp),
                    onClick = { onNavigateToTab("Outfits") }
                ) {
                    Column {
                        // Large image representation with beautiful background gradients & details
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    brush = Brush.linearGradient(
                                        colors = listOf(rec.primaryColor.copy(alpha = 0.7f), rec.secColor.copy(alpha = 0.4f))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            // Specular lighting mesh inside visual photo
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawCircle(
                                    color = Color.White.copy(alpha = 0.25f),
                                    radius = size.width * 0.4f,
                                    center = Offset(size.width * 0.8f, size.height * 0.1f)
                                )
                            }
                            Icon(
                                imageVector = rec.icon,
                                contentDescription = rec.title,
                                tint = Color.White,
                                modifier = Modifier.size(48.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Minimal text
                        Text(
                            text = rec.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.TextDark,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = rec.desc,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = com.example.ui.theme.TextLight
                        )
                    }
                }
            }
        }

        // Statistics/Status Category Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (searchQuery.isEmpty()) "Your Digital Capsule" else "Search Results (${filteredItems.size})",
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.SansSerif,
                color = com.example.ui.theme.TextDark
            )
            if (searchQuery.isEmpty()) {
                Text(
                    text = "See All",
                    fontSize = 13.sp,
                    color = com.example.ui.theme.WardrobePrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onNavigateToTab("Wardrobe") }
                )
            }
        }

        // Horizontal items section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 120.dp), // extra spacer room for the floating dock overlay
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (filteredItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.3f))
                        .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (searchQuery.isEmpty()) "Digitized capsule list is empty. Tap Scan below to start!" else "No matching garments found.",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = com.example.ui.theme.TextLight
                    )
                }
            } else {
                filteredItems.take(5).forEach { item ->
                    Box(
                        modifier = Modifier
                            .width(160.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                            .background(Color.White.copy(alpha = 0.45f))
                            .clickable { onNavigateToTab("Wardrobe") }
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(
                                            try {
                                                Color(android.graphics.Color.parseColor(item.colorHex))
                                            } catch (e: Exception) {
                                                com.example.ui.theme.WardrobePrimary
                                            }
                                        )
                                        .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                                )

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color.White.copy(alpha = 0.6f))
                                        .padding(vertical = 2.dp, horizontal = 6.dp)
                                ) {
                                    Text(
                                        text = item.category,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = com.example.ui.theme.TextLight
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = item.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = com.example.ui.theme.TextDark,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = item.colorName,
                                fontSize = 11.sp,
                                color = com.example.ui.theme.TextLight,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

private val EaseInOutSine = Easing { fraction ->
    -(kotlin.math.cos(Math.PI * fraction) - 1f).toFloat() / 2f
}

data class RecommendationItem(
    val title: String,
    val desc: String,
    val primaryColor: Color,
    val secColor: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
