package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 32.dp,
    onClick: (() -> Unit)? = null,
    borderWidth: Dp = 1.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val clickableModifier = if (onClick != null) {
        Modifier.clickable { onClick() }
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .border(
                border = BorderStroke(borderWidth, Color.White.copy(alpha = 0.55f)),
                shape = RoundedCornerShape(cornerRadius)
            )
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.75f), // Slightly more opaque white for high-end structure
                        Color.White.copy(alpha = 0.45f)
                    )
                )
            )
            .drawBehind {
                // Render an elegant diagonal gloss highlight simulating a reflective glass surface
                val width = size.width
                val height = size.height
                val shadowPathBrush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    start = androidx.compose.ui.geometry.Offset(0f, 0f),
                    end = androidx.compose.ui.geometry.Offset(width * 0.4f, height * 0.6f)
                )
                drawRect(
                    brush = shadowPathBrush
                )
            }
            .then(clickableModifier)
            .padding(20.dp)
    ) {
        content()
    }
}

/**
 * Transparent floating card reflecting full Material 3 dynamic shadows
 */
@Composable
fun FloatingLiquidGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 32.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    // Elevates standard Compose Card with glass styling to make it feel floating
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 0.dp // Low static elevation, styled visually
        )
    ) {
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = cornerRadius,
            onClick = onClick,
            content = content
        )
    }
}
