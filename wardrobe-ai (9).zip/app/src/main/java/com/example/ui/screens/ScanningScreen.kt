package com.example.ui.screens

import android.graphics.PointF
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FloatingLiquidGlassCard
import com.example.ui.components.LiquidGlassCard
import com.example.ui.viewmodel.ScanStatus
import com.example.ui.viewmodel.WardrobeViewModel
import kotlin.math.cos
import kotlin.math.sin

private val EaseInOutSine = Easing { fraction ->
    -(cos(Math.PI * fraction) - 1f).toFloat() / 2f
}

// Spark Particle Seed Data
private data class ParticleSeed(
    val id: Int,
    val xRatio: Float,
    val yRatio: Float,
    val speedY: Float,
    val driftAmp: Float,
    val driftSpeed: Float,
    val baseSize: Float
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScanningScreen(
    viewModel: WardrobeViewModel,
    modifier: Modifier = Modifier
) {
    val scanStatus by viewModel.scanStatus.collectAsState()

    var customItemName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Jeans") }
    var customColorName by remember { mutableStateOf("Classic Indigo Blue") }
    var customColorHex by remember { mutableStateOf("#4B6F96") }
    var customDescription by remember { mutableStateOf("") }

    val categories = listOf("Jeans", "Shirts", "Tshirts", "Hoodies", "Jackets", "Shoes", "Accessories")

    val curatedTrendingScans = listOf(
        TrendingScanItem("Mocha Casual Blazer", "Jackets", "Rich Mocha", "#4E3629", "Relaxed dual pocket tailoring in buttery wool tencel fabric."),
        TrendingScanItem("Sage Slouchy Linen Shirt", "Shirts", "Sage Green", "#8F9E8B", "French-seam utility overshirt in crisp breathable flax linen."),
        TrendingScanItem("Tuscan Rust Knit Vest", "Shirts", "Terracotta Rust", "#C15436", "Hand-loomed heavy rib mock neck knit vest in rich burnt orange."),
        TrendingScanItem("Ink Velvet Corduroy Pant", "Jeans", "Midnight Ink", "#1D2330", "Deep velvet wale corduroy tailored trouser with standard straight leg drape."),
        TrendingScanItem("Burgundy Cordovan Loafers", "Shoes", "Burgundy Cherry", "#601020", "High gloss polished almond toe classic loafer with wood stacked sole.")
    )

    val customColorsProfile = listOf(
        Pair("Indigo Blue", "#4B6F96"),
        Pair("Matcha Green", "#7F8C6F"),
        Pair("Oatmeal Cream", "#EADEC9"),
        Pair("Rich Cocoa", "#3E2723"),
        Pair("Cream Silk", "#FAFAF2"),
        Pair("Sleek Ivory", "#FFFFF5")
    )

    // Base background setup with mesh animation & drifting particles
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E15)) // Minimal premium dark backing
    ) {
        // 1. ANIMATED MESH GRADIENT
        AnimatedMeshGradientBackground()

        // 2. FLOATING PARTICLES
        FloatingAtmosphereParticles()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp)
        ) {
            Spacer(modifier = Modifier.statusBarsPadding())
            Spacer(modifier = Modifier.height(20.dp))

            // Screen Elegant Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI CAPSULE ENGINE",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.5.sp,
                            color = Color(0xFFA0A5C0)
                        )
                    )
                    Text(
                        text = "Stylist Lens",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.SansSerif,
                            color = Color.White
                        )
                    )
                }

                // Apple Inspired Info Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "V 2.5 LENS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF00D4FF),
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (val status = scanStatus) {
                is ScanStatus.Idle -> {
                    // CAMERA VIEW PANEL + HUGE BLUR MASSIVE BUTTON
                    InteractiveCameraViewport(
                        itemName = customItemName,
                        category = selectedCategory,
                        colorName = customColorName,
                        colorHex = customColorHex,
                        description = customDescription,
                        onScanTriggered = {
                            // Ensure a decent fallback if empty
                            val actualName = customItemName.ifBlank { "Modern Tailored Silhouette" }
                            val actualDesc = customDescription.ifBlank { "Unstructured flowing tailored fashion segment." }
                            viewModel.scanShoppingItem(
                                name = actualName,
                                category = selectedCategory,
                                colorName = customColorName,
                                colorHex = customColorHex,
                                description = actualDesc
                            )
                        }
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // INPUT SELECTIONS: Sliding deck for styling configuration
                    Text(
                        text = "CONFIGURE LENS TARGET",
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF90A4AE),
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    FloatingLiquidGlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            // Item Input
                            OutlinedTextField(
                                value = customItemName,
                                onValueChange = { customItemName = it },
                                label = { Text("What piece are you holding?", color = Color.White.copy(alpha = 0.7f)) },
                                placeholder = { Text("e.g. Premium Woolen Trench", color = Color.White.copy(alpha = 0.4f)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White.copy(alpha = 0.9f),
                                    focusedBorderColor = Color(0xFF00D4FF),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.25f),
                                    focusedLabelColor = Color(0xFF00D4FF),
                                    unfocusedLabelColor = Color.White.copy(alpha = 0.6f)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("scan_item_name_input"),
                                shape = RoundedCornerShape(16.dp),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Custom Category Selector Chips
                            Text(
                                text = "Target Category",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                categories.forEach { valCat ->
                                    val isSelected = selectedCategory == valCat
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(
                                                if (isSelected) {
                                                    Brush.linearGradient(listOf(Color(0xFF0052D4), Color(0xFF4364F7)))
                                                } else {
                                                    Brush.linearGradient(listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.03f)))
                                                }
                                            )
                                            .border(
                                                1.dp,
                                                if (isSelected) Color(0xFF00D4FF) else Color.White.copy(alpha = 0.15f),
                                                RoundedCornerShape(14.dp)
                                            )
                                            .clickable { selectedCategory = valCat }
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = valCat,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.8f)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Color swatches row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Detected Color Hue",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = customColorName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00D4FF)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                customColorsProfile.forEach { (name, hex) ->
                                    val isSelected = customColorHex == hex
                                    val colVal = Color(android.graphics.Color.parseColor(hex))
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(colVal)
                                            .border(
                                                width = if (isSelected) 3.dp else 1.2.dp,
                                                color = if (isSelected) Color(0xFF00D4FF) else Color.White.copy(alpha = 0.4f),
                                                shape = CircleShape
                                            )
                                            .clickable {
                                                customColorName = name
                                                customColorHex = hex
                                            }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            OutlinedTextField(
                                value = customDescription,
                                onValueChange = { customDescription = it },
                                label = { Text("Details & Silhouette Notes", color = Color.White.copy(alpha = 0.7f)) },
                                placeholder = { Text("e.g. vintage relaxed fit heavy raw knit fabric", color = Color.White.copy(alpha = 0.4f)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White.copy(alpha = 0.9f),
                                    focusedBorderColor = Color(0xFF00D4FF),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.25f),
                                    focusedLabelColor = Color(0xFF00D4FF),
                                    unfocusedLabelColor = Color.White.copy(alpha = 0.6f)
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                maxLines = 2
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Rapid Scan Presets
                    Text(
                        text = "1-TAP TRENDING SPECIMENS",
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF90A4AE),
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        curatedTrendingScans.forEach { trending ->
                            TrendingScanDarkCard(
                                item = trending,
                                onClick = {
                                    viewModel.scanShoppingItem(
                                        name = trending.name,
                                        category = trending.category,
                                        colorName = trending.colorName,
                                        colorHex = trending.colorHex,
                                        description = trending.description
                                    )
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(120.dp))
                }

                is ScanStatus.Scanning -> {
                    // Apple-Quality immersive morphing & scanning sequence panel
                    CinematicScanningVortex(statusColorHex = customColorHex)
                }

                is ScanStatus.Success -> {
                    // Beautiful high-fidelity standalone result screen in capsule styling
                    AIResultScreen(
                        analysis = status.result,
                        itemName = status.itemName,
                        category = status.category,
                        colorName = status.colorName,
                        colorHex = status.colorHex,
                        description = status.itemDescription,
                        onClear = { viewModel.clearScan() },
                        onSaveToWardrobe = {
                            viewModel.addScannedItemToWardrobe(
                                name = status.itemName,
                                category = status.category,
                                colorName = status.colorName,
                                colorHex = status.colorHex,
                                description = status.itemDescription
                            )
                            viewModel.clearScan()
                        }
                    )
                }

                is ScanStatus.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Outlined.Error,
                                    contentDescription = "Error",
                                    tint = Color(0xFFFF5FA2),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "Tactile Scan Interrupted",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = status.message,
                                    color = Color.White.copy(alpha = 0.7f),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = { viewModel.clearScan() },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF00D4FF)
                                    )
                                ) {
                                    Text("Dismiss Lens", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 1. ANIMATED MESH GRADIENT
 * Custom overlapping radial paint gradients drawn organically via Canvas
 */
@Composable
fun AnimatedMeshGradientBackground() {
    val infiniteTransition = rememberInfiniteTransition(label = "mesh")

    // Shift angles over time
    val angle1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Restart),
        label = "omega1"
    )

    val angle2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Restart),
        label = "omega2"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Fill background black
        drawRect(color = Color(0xFF0A0B10))

        // Center Point 1 (Indigo Gradient)
        val cx1 = w / 2f + cos(angle1) * (w * 0.28f)
        val cy1 = h / 3f + sin(angle1) * (h * 0.15f)

        // Center Point 2 (Deep Violet Orchid Gradient)
        val cx2 = w / 2f + cos(angle2) * (w * 0.35f)
        val cy2 = h * 0.7f + sin(angle2) * (h * 0.2f)

        // Gradient 1 Paint
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF2E0854).copy(alpha = 0.55f), Color.Transparent),
                center = Offset(cx1, cy1),
                radius = w * 1.1f
            ),
            radius = w * 1.1f
        )

        // Gradient 2 Paint
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF0F3BB0).copy(alpha = 0.45f), Color.Transparent),
                center = Offset(cx2, cy2),
                radius = w * 0.95f
            ),
            radius = w * 0.95f
        )

        // Subtle Ambient Mesh cyan mist
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF00D4FF).copy(alpha = 0.08f), Color.Transparent),
                center = Offset(w * 0.1f, h * 0.5f),
                radius = w * 0.6f
            ),
            radius = w * 0.6f
        )
    }
}

/**
 * 2. FLOATING ATMOSPHERE PARTICLES
 * Renders 30 micro sparks moving horizontally & vertically with soft fading
 */
@Composable
fun FloatingAtmosphereParticles() {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient_particles")
    val progress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spark_timer"
    )

    val particles = remember {
        List(32) { i ->
            ParticleSeed(
                id = i,
                xRatio = (0.05f + 0.9f * (i * 1.17f % 1f)),
                yRatio = (0.05f + 0.9f * (i * 1.63f % 1f)),
                speedY = 0.15f + 0.12f * (i * 0.73f % 1f),
                driftAmp = 20f + 30f * (i * 0.47f % 1f),
                driftSpeed = 2f + 3f * (i * 0.29f % 1f),
                baseSize = 2f + 3.5f * (i * 0.82f % 1f)
            )
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        particles.forEach { p ->
            // Shift particle upward based on time progression
            val currentYRatio = (p.yRatio - progress * p.speedY + 1f) % 1f
            val px = p.xRatio * w + sin(progress * p.driftSpeed * 2f * Math.PI.toFloat()) * p.driftAmp
            val py = currentYRatio * h

            // Fade particles out as they approach visual margins
            val alpha = when {
                currentYRatio < 0.15f -> currentYRatio / 0.15f
                currentYRatio > 0.85f -> (1f - currentYRatio) / 0.15f
                else -> 1f
            } * 0.35f

            drawCircle(
                color = Color.White.copy(alpha = alpha),
                radius = p.baseSize,
                center = Offset(px, py)
            )
        }
    }
}

/**
 * 3. INTERACTIVE CAMERA VIEWPORT
 * Implements Apple style rounded camera viewfinder framing the massive glowing tactile button.
 */
@Composable
fun InteractiveCameraViewport(
    itemName: String,
    category: String,
    colorName: String,
    colorHex: String,
    description: String,
    onScanTriggered: () -> Unit
) {
    var isHovered by remember { mutableStateOf(false) }

    // Constants for the Big Tactile Button
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_lens")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(18000 + (1024 % 5000), easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_pulse"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "sweep_laser"
    )

    val targetColor = remember(colorHex) {
        try {
            Color(android.graphics.Color.parseColor(colorHex))
        } catch (e: Exception) {
            Color(0xFF00D4FF)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(310.dp)
            .clip(RoundedCornerShape(32.dp))
            .border(1.2.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(32.dp))
            .background(Color.White.copy(alpha = 0.04f))
    ) {
        // BACKGROUND OF VIEWFINDER: Grid mapping + abstract geometry
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Render camera alignment lines
            val borderPadding = 16.dp.toPx()
            val bracketLen = 22.dp.toPx()

            val linesBrush = SolidColor(Color.White.copy(alpha = 0.05f))
            // Cross grid 3x3 line style
            drawLine(linesBrush, Offset(w / 3f, 0f), Offset(w / 3f, h), strokeWidth = 1f)
            drawLine(linesBrush, Offset(w * 2f / 3f, 0f), Offset(w * 2f / 3f, h), strokeWidth = 1f)
            drawLine(linesBrush, Offset(0f, h / 3f), Offset(w, h / 3f), strokeWidth = 1f)
            drawLine(linesBrush, Offset(0f, h * 2f / 3f), Offset(w, h * 2f / 3f), strokeWidth = 1f)

            // Drawing viewport framing corner angles
            val frameBrush = SolidColor(Color.White.copy(alpha = 0.35f))
            val sw = 2.dp.toPx()

            // Top-Left [
            drawLine(frameBrush, Offset(borderPadding, borderPadding), Offset(borderPadding, borderPadding + bracketLen), sw, StrokeCap.Round)
            drawLine(frameBrush, Offset(borderPadding, borderPadding), Offset(borderPadding + bracketLen, borderPadding), sw, StrokeCap.Round)

            // Top-Right ]
            drawLine(frameBrush, Offset(w - borderPadding, borderPadding), Offset(w - borderPadding, borderPadding + bracketLen), sw, StrokeCap.Round)
            drawLine(frameBrush, Offset(w - borderPadding, borderPadding), Offset(w - borderPadding - bracketLen, borderPadding), sw, StrokeCap.Round)

            // Bottom-Left
            drawLine(frameBrush, Offset(borderPadding, h - borderPadding), Offset(borderPadding, h - borderPadding - bracketLen), sw, StrokeCap.Round)
            drawLine(frameBrush, Offset(borderPadding, h - borderPadding), Offset(borderPadding + bracketLen, h - borderPadding), sw, StrokeCap.Round)

            // Bottom-Right
            drawLine(frameBrush, Offset(w - borderPadding, h - borderPadding), Offset(w - borderPadding, h - borderPadding - bracketLen), sw, StrokeCap.Round)
            drawLine(frameBrush, Offset(w - borderPadding, h - borderPadding), Offset(w - borderPadding - bracketLen, h - borderPadding), sw, StrokeCap.Round)
        }

        // CENTERED MASSIVE SHINING GLASS TACTILE BUTTON
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            // Underling massive pulsing blue glow (Blur emulation via overlapping radial paints)
            Box(
                modifier = Modifier
                    .size(170.dp)
                    .graphicsLayer {
                        scaleX = pulseScale
                        scaleY = pulseScale
                    }
                    .drawBehind {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF00D4FF).copy(alpha = glowAlpha * 0.38f),
                                    Color(0xFF4364F7).copy(alpha = glowAlpha * 0.15f),
                                    Color.Transparent
                                ),
                                center = Offset(size.width / 2f, size.height / 2f),
                                radius = size.width * 0.45f
                            ),
                            radius = size.width * 0.5f
                        )
                    }
            )

            // Actual Outer Glass boundary with micro gloss spec
            Box(
                modifier = Modifier
                    .size(125.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f))
                    .border(1.5.dp, Color.White.copy(alpha = 0.45f), CircleShape)
                    .clickable { onScanTriggered() }
                    .drawBehind {
                        val w = size.width
                        val h = size.height

                        // Specular Light sweep
                        val lightSweep = Brush.linearGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.15f),
                                Color.Transparent,
                                Color.White.copy(alpha = 0.08f)
                            ),
                            start = Offset(0f, 0f),
                            end = Offset(w * 0.6f, h)
                        )
                        drawCircle(brush = lightSweep)

                        // Outer revolving neon blue pointer tick
                        drawArc(
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    Color(0xFF00D4FF),
                                    Color.Transparent
                                )
                            ),
                            startAngle = sweepAngle,
                            sweepAngle = 90f,
                            useCenter = false,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                    .testTag("scan_activate_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                            .border(1.2.dp, Color.White.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Scan Icon",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "TOUCH TO AUDIT",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // VIEWPORT CORNER SPECIMEN INFO OVERLAY
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(20.dp)
                .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(targetColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (itemName.isNotBlank()) itemName.take(16) else "Auto Aim Ready",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(alpha = 0.9f)
                )
            }
        }
    }
}

/**
 * 4. CINEMATIC SCANNING VORTEX
 * Captures scanning states: Scanning..., Analyzing Colors..., Matching Wardrobe..., Generating Outfits...
 * and loops breathtaking custom Canvas effects (Radar Sweep, Glass Ripple, Particles, Light Rays, Blur Morph).
 */
@Composable
fun CinematicScanningVortex(statusColorHex: String) {
    val steps = listOf(
        "Scanning target specimen...",
        "Analyzing pigment hue matrices...",
        "Querying Gemini fashion network...",
        "Synthesizing customized wardrobe outfits..."
    )

    var stepIdx by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        val delayTime = 1200L
        while (stepIdx < steps.size - 1) {
            kotlinx.coroutines.delay(delayTime)
            stepIdx++
        }
    }

    val themeColor = remember(statusColorHex) {
        try {
            Color(android.graphics.Color.parseColor(statusColorHex))
        } catch (e: Exception) {
            Color(0xFF00D4FF)
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "scanning_core")

    // Animations corresponding to sweep, pulse and light rays
    val scanY by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 280f,
        animationSpec = infiniteRepeatable(tween(2200, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "scanner_line"
    )

    val sonarScale by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart),
        label = "sonar_ripple"
    )

    val sonarAlpha by animateFloatAsState(
        targetValue = 1f - ((sonarScale - 0.3f) / 1.0f).coerceIn(0f, 1f),
        animationSpec = tween(100),
        label = "sonar_alpha"
    )

    val lightRayRot by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(10000, easing = LinearEasing)),
        label = "ray_rot"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // IMMERSIVE MULTI-LAYER SCANNER CONTAINER
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .border(1.2.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(32.dp))
                    .background(Color.White.copy(alpha = 0.04f))
            ) {
                // 1. Radar Sweep, Sonar pulse, and Specimen silhouette matrix
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val cx = w / 2f
                    val cy = h / 2f

                    // Radial glowing backdrop matching detected hue
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(themeColor.copy(alpha = 0.15f), Color.Transparent),
                            center = Offset(cx, cy),
                            radius = w * 0.45f
                        ),
                        radius = w * 0.5f
                    )

                    // Rotating Light Ray projections
                    val rayCount = 12
                    val sweepAngleRad = Math.toRadians(lightRayRot.toDouble())
                    for (i in 0 until rayCount) {
                        val baseRad = (i * 2 * Math.PI / rayCount) + sweepAngleRad
                        val xEnd = cx + cos(baseRad).toFloat() * (w * 0.6f)
                        val yEnd = cy + sin(baseRad).toFloat() * (h * 0.6f)
                        drawLine(
                            color = themeColor.copy(alpha = 0.08f),
                            start = Offset(cx, cy),
                            end = Offset(xEnd, yEnd),
                            strokeWidth = 3f
                        )
                    }

                    // Sonar ring expansion
                    drawCircle(
                        color = themeColor.copy(alpha = sonarAlpha * 0.45f),
                        radius = (w * 0.5f) * sonarScale,
                        center = Offset(cx, cy),
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Target focal bracket mapping representing "Specimen alignment"
                    drawCircle(
                        color = Color.White.copy(alpha = 0.2f),
                        radius = w * 0.18f,
                        center = Offset(cx, cy)
                    )

                    // Animated Scanning Laser Bar
                    drawLine(
                        brush = Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, themeColor, Color.Transparent)
                        ),
                        start = Offset(0f, scanY.dp.toPx()),
                        end = Offset(w, scanY.dp.toPx()),
                        strokeWidth = 4.dp.toPx()
                    )
                }

                // Inner core spinning glass plate
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.07f))
                        .border(1.2.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                        .graphicsLayer {
                            rotationZ = lightRayRot * 2f
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Glowing core",
                        tint = themeColor,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // STEP STATUS PRINTS (Minimal premium monospace/sans combo)
            Text(
                text = steps[stepIdx],
                fontSize = 14.sp,
                color = themeColor,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .animateContentSize()
            )
            Spacer(modifier = Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { (stepIdx + 1) / 4f },
                modifier = Modifier
                    .width(180.dp)
                    .height(6.dp)
                    .clip(CircleShape),
                color = themeColor,
                trackColor = Color.White.copy(alpha = 0.08f)
            )
        }
    }
}

/**
 * 5. SUCCESS ANALYTICAL PANE
 * Renders the beautiful stylist recommendations & combo listings
 */
@Composable
fun SuccessAnalyticalPane(
    analysis: com.example.api.WardrobeAnalysisResult,
    itemName: String,
    category: String,
    colorName: String,
    colorHex: String,
    description: String,
    onClear: () -> Unit,
    onSaveToWardrobe: () -> Unit,
    modifier: Modifier = Modifier
) {
    val themeColor = remember(colorHex) {
        try {
            Color(android.graphics.Color.parseColor(colorHex))
        } catch (e: Exception) {
            Color(0xFF00D4FF)
        }
    }

    val isBuy = analysis.recommendation.uppercase() == "BUY"

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Specimen Image Box representation
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.85f)
                .clip(RoundedCornerShape(28.dp))
                .border(1.2.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(28.dp))
                .background(Color.White.copy(alpha = 0.04f))
        ) {
            // Full Specimen viewport
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
                    .clip(RoundedCornerShape(20.dp))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Dynamic stylized abstract mesh inside
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(themeColor.copy(alpha = 0.45f), themeColor.copy(alpha = 0.75f).compositeOver(Color.DarkGray)),
                            start = Offset(0f, 0f),
                            end = Offset(w, h)
                        )
                    )

                    // Draw focus target inside graphic
                    drawCircle(
                        color = Color.White.copy(alpha = 0.15f),
                        radius = w * 0.28f,
                        center = Offset(w / 2f, h * 0.45f)
                    )
                }

                // Glass Ripple sweep overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.04f), Color.Transparent)
                            )
                        )
                )
            }

            // Compatibility Score Overlay (Upper Right corner)
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(32.dp)
                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(14.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "COMPATIBLE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF00D4FF),
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "${analysis.compatibilityScore}%",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }

            // Main spec text block (Bottom absolute)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(26.dp)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "CAPSULE CLASSIFICATION",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.6f),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = itemName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$category • $colorName",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Palette Swatch + Outfit Statistics Segment
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Pigment Swatch
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .padding(14.dp)
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(themeColor)
                            .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "PIGMENT",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                    Text(
                        text = colorName,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Fitted Match Count
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .padding(14.dp)
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00D4FF).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Checkroom,
                            contentDescription = null,
                            tint = Color(0xFF00D4FF),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "INTEGRATION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                    Text(
                        text = "${analysis.matchingOutfits.size} Combo Outfits",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Stylist Verdict & Combo listings inside translucent glass layout card
        LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(
                    text = "Stylist Audit Reasoning",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = analysis.reasoning,
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.85f),
                    lineHeight = 20.sp
                )

                Divider(color = Color.White.copy(alpha = 0.12f))

                // Capsule Combos list representation
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color(0xFF00D4FF),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Synthesized Combinations",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    analysis.matchingOutfits.forEach { combo ->
                        Row(verticalAlignment = Alignment.Top) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 5.dp)
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00D4FF))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = combo,
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.8f),
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                Divider(color = Color.White.copy(alpha = 0.12f))

                // Base Items Needed segment
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = null,
                            tint = Color(0xFFFF5FA2),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Useful Capsule Amplifiers Needed",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Text(
                        text = analysis.keyItemsNeeded.joinToString(", "),
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }

                Divider(color = Color.White.copy(alpha = 0.12f))

                // Color Suitability Harmony Segment
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = Color(0xFF7C4DFF),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Contrast Harmony Directions",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Text(
                        text = analysis.colorHarmony,
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f),
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Action Buttons Row (Floating layout model at screen bottom)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(24.dp)
                )
                .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "LENS VERDICT",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.5f),
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = if (isBuy) "Highly Recommended" else "Skip Specification",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isBuy) Color(0xFF00D4FF) else Color(0xFFFF5FA2)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onClear,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color.White
                        ),
                        border = BorderStroke(1.2.dp, Color.White.copy(alpha = 0.25f))
                    ) {
                        Text("Reset", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onSaveToWardrobe,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isBuy) Color(0xFF00D4FF) else Color(0xFF4285F4)
                        ),
                        modifier = Modifier.testTag("save_and_integrate_button")
                    ) {
                        Text(
                            text = if (isBuy) "BUY & ADD" else "ADD TO PIECES",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Custom trending scan cards for premium dark aesthetic
 */
@Composable
fun TrendingScanDarkCard(
    item: TrendingScanItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val specimenColor = remember(item.colorHex) {
        try {
            Color(android.graphics.Color.parseColor(item.colorHex))
        } catch (e: Exception) {
            Color(0xFF00D4FF)
        }
    }

    Box(
        modifier = modifier
            .width(170.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(specimenColor)
                    .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = item.name,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = item.category,
                fontSize = 11.sp,
                color = Color(0xFF00D4FF),
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = item.description,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 13.sp
            )
        }
    }
}

data class TrendingScanItem(
    val name: String,
    val category: String,
    val colorName: String,
    val colorHex: String,
    val description: String
)

/*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🍎 DEEPMIND LABS FLUTTER SYNCHRONOUS DOCUMENTATION & DART EQUIVALENT GRAPHICS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

To implement this Apple Quality Glass Scan Lens screen perfectly inside Flutter:

1. ANIMATED MESH GRADIENT (Flutter Dart Equivalent):
Use a CustomPainter that utilizes multiple radial gradients combined with custom blending models
using `BlendMode.screen` or `BlendMode.sourceOver` combined with an `AnimationController` that shifts focal points over time.

```dart
class MeshGradientPainter extends CustomPainter {
  final double progress;
  MeshGradientPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final paintBase = Paint()..color = const Color(0xFF0A0B10);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), paintBase);

    // Orbit coordinates dynamic computation
    final angle = progress * 2.0 * math.pi;
    final cx1 = size.width / 2.0 + math.cos(angle) * (size.width * 0.28);
    final cy1 = size.height / 3.0 + math.sin(angle) * (size.height * 0.15);

    final List<Color> colors1 = [const Color(0xFF2E0854).withOpacity(0.55), Colors.transparent];
    final paint1 = Paint()
      ..shader = ui.Gradient.radial(
        Offset(cx1, cy1),
        size.width * 1.1,
        colors1,
      );
    canvas.drawCircle(Offset(cx1, cy1), size.width * 1.1, paint1);
  }

  @override
  bool shouldRepaint(covariant MeshGradientPainter oldDelegate) => oldDelegate.progress != progress;
}
```

2. FLOATING SPARK PARTICLES (Flutter Dart Equivalent):
Create a particle model class tracking offsets and update their state inside a `TickerProviderStateMixin` or
render them via `AnimatedBuilder` combined with a CustomPainter.

3. GLASS MORPH TOUCH SCAN BUTTON (Flutter Dart Equivalent):
Use Flutter's `BackdropFilter` combined with `ImageFilter.blur(sigmaX: 50, sigmaY: 50)`
wrapped inside a circular container decorated with a premium white semi-transparent linear gradient border decoration.

```dart
ClipOval(
  child: BackdropFilter(
    filter: ImageFilter.blur(sigmaX: 50, sigmaY: 50),
    child: Container(
      width: 125,
      height: 125,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withOpacity(0.08),
        border: Border.all(color: Colors.white.withOpacity(0.45), width: 1.5),
      ),
      child: const Center(child: Icon(Icons.camera_alt, color: Colors.white)),
    ),
  ),
)
```
*/
