package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wardrobe_items")
data class WardrobeItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String, // "Tops", "Bottoms", "Outerwear", "Shoes", "Accessories"
    val colorName: String, // e.g. "Cream Velvet", "Midnight Black"
    val colorHex: String, // e.g. "#FFFDD0"
    val description: String? = null,
    val imageUrl: String? = null,
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
