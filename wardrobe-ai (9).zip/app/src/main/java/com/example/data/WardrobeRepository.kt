package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class WardrobeRepository(private val wardrobeDao: WardrobeDao) {
    val allItems: Flow<List<WardrobeItem>> = wardrobeDao.getAllItems()

    fun getItemsByCategory(category: String): Flow<List<WardrobeItem>> {
        return wardrobeDao.getItemsByCategory(category)
    }

    suspend fun getItemById(id: Int): WardrobeItem? = withContext(Dispatchers.IO) {
        wardrobeDao.getItemById(id)
    }

    suspend fun insert(item: WardrobeItem) = withContext(Dispatchers.IO) {
        wardrobeDao.insertItem(item)
    }

    suspend fun delete(item: WardrobeItem) = withContext(Dispatchers.IO) {
        wardrobeDao.deleteItem(item)
    }

    suspend fun deleteById(id: Int) = withContext(Dispatchers.IO) {
        wardrobeDao.deleteItemById(id)
    }

    suspend fun seedInitialDataIfNecessary() = withContext(Dispatchers.IO) {
        val count = wardrobeDao.getCount()
        if (count == 0) {
            val seedItems = listOf(
                WardrobeItem(
                    name = "Vintage Indigo Denim 501",
                    category = "Jeans",
                    colorName = "Classic Indigo Blue",
                    colorHex = "#4B6F96",
                    description = "Straight-fit heavyweight selvedge denim with iconic contrast stitching and heritage copper rivets."
                ),
                WardrobeItem(
                    name = "Midnight Black Slouchy Jeans",
                    category = "Jeans",
                    colorName = "Charcoal Black",
                    colorHex = "#1D1E2C",
                    description = "Relaxed-fit faded denim pants with custom knee distressing and tailored waist taper."
                ),
                WardrobeItem(
                    name = "Silk Off-White Button-Up",
                    category = "Shirts",
                    colorName = "Cream Silk",
                    colorHex = "#FAFAF2",
                    description = "Flowy organic mulberry silk collared shirt, clean button line, airy silhouette."
                ),
                WardrobeItem(
                    name = "Linen Sage Over-Shirt",
                    category = "Shirts",
                    colorName = "Sage Green",
                    colorHex = "#9CAF88",
                    description = "Light breathable French linen shirt, casual button jacket style, summer luxury drape."
                ),
                WardrobeItem(
                    name = "Vanilla Heavyweight Boxy Tee",
                    category = "Tshirts",
                    colorName = "Warm Vanilla",
                    colorHex = "#FFF5E6",
                    description = "Chunky knit raw cotton crewneck tee with comfortable dropped shoulders."
                ),
                WardrobeItem(
                    name = "Oatmeal Fleece Cozy Hoodie",
                    category = "Hoodies",
                    colorName = "Cozy Oatmeal",
                    colorHex = "#E5DCD3",
                    description = "Ultra-soft Brushed fleece hoodie with cross-over front detail and dropped shoulders."
                ),
                WardrobeItem(
                    name = "Retro Washed Blue Denim Jacket",
                    category = "Jackets",
                    colorName = "Washed Indigo Blue",
                    colorHex = "#648BB5",
                    description = "Oversized classic jean jacket featuring dual chest pockets and silver button hardware."
                ),
                WardrobeItem(
                    name = "Slate Grey Tailored Blazer",
                    category = "Jackets",
                    colorName = "French Slate",
                    colorHex = "#7A8A99",
                    description = "Minimalist unstructured soft blazer with structured shoulders in light knit fabric."
                ),
                WardrobeItem(
                    name = "Chalk Minimalist Leather Sneaker",
                    category = "Shoes",
                    colorName = "Chalk Off-White",
                    colorHex = "#F4F3F0",
                    description = "Premium minimalist low-top sneakers in buttery Italian calf leather."
                ),
                WardrobeItem(
                    name = "Classic Black Leather Loafers",
                    category = "Shoes",
                    colorName = "Gloss Midnight Black",
                    colorHex = "#111116",
                    description = "Timeless almond-toe penny loafers handcrafted in full-grain polished calfskin."
                ),
                WardrobeItem(
                    name = "Silver Premium Herringbone Chain",
                    category = "Accessories",
                    colorName = "Radiant Silver",
                    colorHex = "#C0C0C0",
                    description = "Seamless shiny flat-woven sterling silver neckpiece with custom lobster clasp."
                )
            )
            for (item in seedItems) {
                wardrobeDao.insertItem(item)
            }
        }
    }
}
