package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.WardrobeViewModel
import com.example.ui.screens.MainAppScreen

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    
    // Enable edge-to-edge drawing under the system bars
    enableEdgeToEdge()
    
    // Instantiate our unified State provider with the customized capsule database
    val viewModel = ViewModelProvider(
      this, 
      WardrobeViewModel.Factory(application)
    )[WardrobeViewModel::class.java]

    setContent {
      MyApplicationTheme {
        MainAppScreen(viewModel = viewModel)
      }
    }
  }
}
